const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { resolve } = require('../server');

const ROOT = path.join(__dirname, '..');

test('server: serves the page, styles, sources and docs', () => {
  assert.equal(resolve('/'), path.join(ROOT, 'index.html'));
  assert.equal(resolve('/index.html'), path.join(ROOT, 'index.html'));
  assert.equal(resolve('/css/style.css'), path.join(ROOT, 'css', 'style.css'));
  assert.equal(resolve('/src/engine.js'), path.join(ROOT, 'src', 'engine.js'));
  assert.equal(resolve('/src/ui/charts.js?v=2'), path.join(ROOT, 'src', 'ui', 'charts.js'));
});

test('server: never leaves the project folder', () => {
  assert.equal(resolve('/../package.json'), null);
  assert.equal(resolve('/src/../../etc/passwd'), null);
  assert.equal(resolve('/%2e%2e/%2e%2e/etc/passwd'), null);
  assert.equal(resolve('/src/%2e%2e/%2e%2e/etc/passwd'), null);
});

test('server: keeps tests, scripts and package files private', () => {
  assert.equal(resolve('/test/engine.test.js'), null);
  assert.equal(resolve('/scripts/bundle.js'), null);
  assert.equal(resolve('/package.json'), null);
  assert.equal(resolve('/server.js'), null);
});

test('server: rejects malformed or null-byte paths', () => {
  assert.equal(resolve('/%E0%A4%A'), null);
  assert.equal(resolve('/index.html%00.png'), null);
});
