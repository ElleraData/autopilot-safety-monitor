const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { bundle } = require('../scripts/bundle');

const page = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');

test('bundle: inlines every local script and stylesheet', () => {
  const out = bundle(page);
  assert.ok(!/<script[^>]*\ssrc="(?!https?:)/.test(out), 'no local script tags are left');
  assert.ok(!/<link[^>]*href="css\//.test(out), 'no local stylesheet link is left');
  assert.ok(out.includes('<style>'));
  assert.equal((out.match(/<script>/g) || []).length, 1, 'one combined script');
});

test('bundle: keeps external links and the page markup', () => {
  const out = bundle(page);
  assert.ok(out.includes('fonts.googleapis.com'));
  assert.ok(out.includes('id="roadView"'));
  assert.ok(out.includes('<title>Autopilot Telemetry</title>'));
});

test('bundle: scripts keep their order, so each module finds the one before it', () => {
  const out = bundle(page);
  const order = ['src/config.js', 'src/rng.js', 'src/engine.js', 'src/generator.js', 'src/scenarios.js', 'src/ui/car-side.js', 'src/ui/road-view.js', 'src/ui/charts.js', 'src/app.js'];
  const at = order.map((name) => out.indexOf('/* ' + name + ' */'));
  at.forEach((n, i) => assert.ok(n >= 0, order[i] + ' is present'));
  assert.deepEqual([...at].sort((a, b) => a - b), at);
});

test('bundle: a closing script tag inside a source file cannot end the script early', () => {
  const html = '<script src="src/config.js"></script>';
  const out = bundle(html);
  const body = out.slice(out.indexOf('<script>') + 8, out.lastIndexOf('</script>'));
  assert.ok(!/<\/script/i.test(body));
});
