const test = require('node:test');
const assert = require('node:assert/strict');
const engine = require('../src/engine');
const config = require('../src/config');

const stock = engine.resolveVehicle('ev-sedan', []);

/** A sample that triggers nothing: slow, clear, far object, no glare. */
function calm(overrides) {
  return Object.assign({ index: 0, label: 'T1', speedKmh: 50, glarePct: 20, distanceM: 300, weather: 'Clear' }, overrides);
}
const statusOf = (sample, vehicle) => engine.evaluateScan(sample, vehicle || stock).status;

// ---------------------------------------------------------------- physics

test('stopping distance: EV Sedan at 66 km/h in clear weather is 33.0 m', () => {
  assert.equal(engine.stoppingDistanceM(66, stock, 'Clear').toFixed(1), '33.0');
});

test('stopping distance: reaction and braking parts add up to the total', () => {
  const part = engine.stoppingBreakdown(72, stock, 'Fog');
  assert.ok(Math.abs(part.reactionM + part.brakingM - part.totalM) < 1e-9);
  assert.ok(Math.abs(part.reactionM - 20 * 0.5) < 1e-9); // 72 km/h = 20 m/s, 0.5 s
});

test('stopping distance: zero speed needs zero distance', () => {
  assert.equal(engine.stoppingDistanceM(0, stock, 'Clear'), 0);
});

test('stopping distance: rain is longer than fog, fog is longer than clear', () => {
  [30, 60, 90, 120].forEach((kmh) => {
    const clear = engine.stoppingDistanceM(kmh, stock, 'Clear');
    const fog = engine.stoppingDistanceM(kmh, stock, 'Fog');
    const rain = engine.stoppingDistanceM(kmh, stock, 'Heavy Rain');
    assert.ok(rain > fog && fog > clear, 'at ' + kmh + ' km/h');
  });
});

test('stopping distance: unknown weather throws instead of guessing', () => {
  assert.throws(() => engine.stoppingDistanceM(50, stock, 'Snow'), /Unknown weather/);
});

test('time to collision: 89 m at 66 km/h is 4.85 s', () => {
  assert.equal(engine.timeToCollisionS(89, 66).toFixed(2), '4.85');
});

test('time to collision: a stopped vehicle never collides', () => {
  assert.equal(engine.timeToCollisionS(10, 0), Infinity);
  assert.equal(statusOf(calm({ speedKmh: 0, distanceM: 5 })), 'SAFE');
});

// ---------------------------------------------------------------- vehicle and modifications

test('vehicle: stock profile matches the config', () => {
  assert.deepEqual(
    { mu: stock.mu, brake: stock.brakeEfficiency, reaction: stock.reactionTimeS },
    { mu: 0.8, brake: 0.9, reaction: 0.5 }
  );
});

test('vehicle: modifications change grip and brakes by their documented amounts', () => {
  assert.equal(engine.resolveVehicle('ev-sedan', ['performanceTires']).mu, 0.9);
  assert.equal(engine.resolveVehicle('ev-sedan', ['wornTires']).mu, 0.65);
  assert.equal(engine.resolveVehicle('ev-sedan', ['upgradedBrakes']).brakeEfficiency, 0.95);
});

test('vehicle: the same modification is applied once', () => {
  const twice = engine.resolveVehicle('ev-sedan', ['upgradedBrakes', 'upgradedBrakes']);
  assert.equal(twice.brakeEfficiency, 0.95);
  assert.deepEqual(twice.mods, ['upgradedBrakes']);
});

test('vehicle: brake efficiency never exceeds 1.0', () => {
  const catalog = {
    profiles: { x: { id: 'x', name: 'X', mu: 0.8, brakeEfficiency: 0.98, reactionTimeS: 0.5 } },
    mods: config.mods,
    limits: config.limits,
  };
  assert.equal(engine.resolveVehicle('x', ['upgradedBrakes'], catalog).brakeEfficiency, 1);
});

test('vehicle: unknown profile or modification throws', () => {
  assert.throws(() => engine.resolveVehicle('nope', []), /Unknown vehicle profile/);
  assert.throws(() => engine.resolveVehicle('ev-sedan', ['turbo']), /Unknown modification/);
});

test('modifications: worn tires never give a shorter stopping distance than the base profile', () => {
  const worn = engine.resolveVehicle('ev-sedan', ['wornTires']);
  ['Clear', 'Fog', 'Heavy Rain'].forEach((weather) => {
    for (let kmh = 0; kmh <= 160; kmh += 5) {
      assert.ok(
        engine.stoppingDistanceM(kmh, worn, weather) >= engine.stoppingDistanceM(kmh, stock, weather),
        weather + ' at ' + kmh + ' km/h'
      );
    }
  });
});

test('modifications: performance tires and upgraded brakes never lengthen the stopping distance', () => {
  const better = engine.resolveVehicle('ev-sedan', ['performanceTires', 'upgradedBrakes']);
  ['Clear', 'Fog', 'Heavy Rain'].forEach((weather) => {
    for (let kmh = 0; kmh <= 160; kmh += 5) {
      assert.ok(engine.stoppingDistanceM(kmh, better, weather) <= engine.stoppingDistanceM(kmh, stock, weather));
    }
  });
});

test('modifications: rain raises the stopping distance for every vehicle setup', () => {
  [[], ['wornTires'], ['performanceTires'], ['upgradedBrakes']].forEach((mods) => {
    const v = engine.resolveVehicle('ev-sedan', mods);
    assert.ok(engine.stoppingDistanceM(70, v, 'Heavy Rain') > engine.stoppingDistanceM(70, v, 'Clear'));
  });
});

// ---------------------------------------------------------------- rule boundaries

test('rule: the documented example, 72 km/h with an object at 11 m in fog, is CRITICAL', () => {
  assert.equal(statusOf(calm({ speedKmh: 72, distanceM: 11, weather: 'Fog', glarePct: 26 })), 'CRITICAL');
});

test('rule: TTC is CRITICAL below 2 s and not at exactly 2 s', () => {
  // 36 km/h = 10 m/s, so 20 m is exactly 2.00 s
  assert.equal(statusOf(calm({ speedKmh: 36, distanceM: 20 })), 'WARNING');
  assert.equal(statusOf(calm({ speedKmh: 36, distanceM: 19 })), 'CRITICAL');
});

test('rule: TTC is WARNING below 4 s and SAFE at exactly 4 s', () => {
  assert.equal(statusOf(calm({ speedKmh: 36, distanceM: 40 })), 'SAFE');
  assert.equal(statusOf(calm({ speedKmh: 36, distanceM: 39 })), 'WARNING');
});

test('rule: object inside the stopping distance is CRITICAL even when TTC looks fine', () => {
  // At 120 km/h in heavy rain the car needs about 148 m to stop, while 140 m is still 4.2 s away.
  const sample = calm({ speedKmh: 120, distanceM: 140, weather: 'Heavy Rain' });
  const result = engine.evaluateScan(sample, stock);
  assert.ok(result.ttcS > 4);
  assert.ok(sample.distanceM < result.stoppingDistanceM);
  assert.equal(result.status, 'CRITICAL');
  assert.match(result.reasons[0], /inside the 147\.8 m stopping distance/);
});

test('rule: the 1.5x stopping-distance warning starts below 1.5x and not above it', () => {
  // 70 km/h in heavy rain: stopping distance 54.3 m, so the limit is 81.5 m. TTC is above 4 s in both cases.
  const inside = engine.evaluateScan(calm({ speedKmh: 70, distanceM: 80, weather: 'Heavy Rain' }), stock);
  const outside = engine.evaluateScan(calm({ speedKmh: 70, distanceM: 83, weather: 'Heavy Rain' }), stock);
  assert.ok(inside.reasons.some((r) => /within 1\.5× the stopping distance \(81\.5 m\)/.test(r)));
  assert.ok(!outside.reasons.some((r) => /stopping distance/.test(r)));
  assert.equal(inside.status, 'WARNING');
});

test('rule: speed is WARNING at 90 km/h and SAFE at 89 km/h', () => {
  assert.equal(statusOf(calm({ speedKmh: 90 })), 'WARNING');
  assert.equal(statusOf(calm({ speedKmh: 89 })), 'SAFE');
});

test('rule: a scenario can set its own speed alert, and the default applies without one', () => {
  const motorway = { speedAlertKmh: 110 };
  assert.equal(engine.evaluateScan(calm({ speedKmh: 100 }), stock, motorway).status, 'SAFE');
  assert.equal(engine.evaluateScan(calm({ speedKmh: 110 }), stock, motorway).status, 'WARNING');
  assert.match(engine.evaluateScan(calm({ speedKmh: 112 }), stock, motorway).reasons[0], /at or above 110 km\/h/);
  const city = { speedAlertKmh: 60 };
  assert.equal(engine.evaluateScan(calm({ speedKmh: 60 }), stock, city).status, 'WARNING');
  assert.equal(engine.evaluateScan(calm({ speedKmh: 59 }), stock, city).status, 'SAFE');
  assert.equal(engine.speedAlertKmh(), 90);
  assert.equal(engine.speedAlertKmh({}), 90);
  assert.equal(engine.speedAlertKmh({ speedAlertKmh: 0 }), 90);
});

test('rule: evaluateRun passes the speed alert on to every scan', () => {
  const samples = [calm({ index: 0, speedKmh: 100 }), calm({ index: 1, speedKmh: 100 })];
  assert.deepEqual(engine.evaluateRun(samples, stock, { speedAlertKmh: 110 }).counts, { SAFE: 2, WARNING: 0, CRITICAL: 0 });
  assert.deepEqual(engine.evaluateRun(samples, stock).counts, { SAFE: 0, WARNING: 2, CRITICAL: 0 });
});

test('rule: camera glare is WARNING at 60% and SAFE at 59%', () => {
  assert.equal(statusOf(calm({ glarePct: 60 })), 'WARNING');
  assert.equal(statusOf(calm({ glarePct: 59 })), 'SAFE');
});

test('rule: fog is WARNING above 60 km/h and SAFE at 60 km/h', () => {
  assert.equal(statusOf(calm({ weather: 'Fog', speedKmh: 61 })), 'WARNING');
  assert.equal(statusOf(calm({ weather: 'Fog', speedKmh: 60 })), 'SAFE');
});

test('rule: heavy rain is WARNING above 50 km/h and SAFE at 50 km/h', () => {
  assert.equal(statusOf(calm({ weather: 'Heavy Rain', speedKmh: 51 })), 'WARNING');
  assert.equal(statusOf(calm({ weather: 'Heavy Rain', speedKmh: 50 })), 'SAFE');
});

test('rule: clear weather has no speed limit of its own', () => {
  assert.equal(statusOf(calm({ weather: 'Clear', speedKmh: 89 })), 'SAFE');
});

// ---------------------------------------------------------------- reasons and severity

test('reasons: a calm scan says no rule was triggered', () => {
  assert.deepEqual(engine.evaluateScan(calm(), stock).reasons, ['No alert rules triggered.']);
});

test('reasons: TTC reason names the value and the threshold', () => {
  const result = engine.evaluateScan(calm({ speedKmh: 36, distanceM: 35 }), stock);
  assert.equal(result.status, 'WARNING');
  assert.equal(result.reasons[0], 'TTC 3.50 s is below 4 s');
});

test('reasons: critical reasons come before warning reasons and CRITICAL wins', () => {
  const result = engine.evaluateScan(calm({ speedKmh: 95, distanceM: 20, glarePct: 70 }), stock);
  assert.equal(result.status, 'CRITICAL');
  assert.match(result.reasons[0], /TTC .* is below 2 s/);
  assert.ok(result.reasons.some((r) => /glare/.test(r)));
  assert.ok(result.reasons.some((r) => /Speed 95/.test(r)));
});

test('reasons: one rule never reports both its warning and critical form', () => {
  const result = engine.evaluateScan(calm({ speedKmh: 50, distanceM: 10 }), stock);
  const ttcReasons = result.reasons.filter((r) => r.startsWith('TTC'));
  assert.equal(ttcReasons.length, 1);
});

// ---------------------------------------------------------------- run evaluation

test('run: counts add up and worstIndex points at the first most severe scan', () => {
  const samples = [
    calm({ index: 0 }),
    calm({ index: 1, speedKmh: 95 }),
    calm({ index: 2, speedKmh: 36, distanceM: 10 }),
    calm({ index: 3, speedKmh: 36, distanceM: 10 }),
  ];
  const run = engine.evaluateRun(samples, stock);
  assert.deepEqual(run.counts, { SAFE: 1, WARNING: 1, CRITICAL: 2 });
  assert.equal(run.worstIndex, 2);
  assert.equal(run.scans.length, 4);
});
