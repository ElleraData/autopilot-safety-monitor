const test = require('node:test');
const assert = require('node:assert/strict');
const engine = require('../src/engine');
const scenarios = require('../src/scenarios');
const { generateRun } = require('../src/generator');

const stock = engine.resolveVehicle('ev-sedan', []);
const better = engine.resolveVehicle('ev-sedan', ['performanceTires', 'upgradedBrakes']);
const worn = engine.resolveVehicle('ev-sedan', ['wornTires']);

// A scenario carries its own speed alert, so it is passed to the engine as the options.
function runOf(scenario, vehicle, seed) {
  return engine.evaluateRun(generateRun(seed === undefined ? scenario.seed : seed, scenario), vehicle || stock, scenario);
}

test('scenarios: three presets exist and Rainy city is the default', () => {
  assert.deepEqual(
    scenarios.list.map((s) => s.id),
    ['highway-cruise', 'rainy-city', 'emergency-braking']
  );
  assert.equal(scenarios.DEFAULT_ID, 'rainy-city');
  assert.ok(scenarios.getScenario(scenarios.DEFAULT_ID));
  assert.equal(scenarios.getScenario('nope'), null);
});

scenarios.list.forEach((scenario) => {
  test('scenario ' + scenario.id + ': produces its expected status mix', () => {
    assert.deepEqual(runOf(scenario).counts, scenario.expectedMix);
  });

  test('scenario ' + scenario.id + ': has at least one SAFE, WARNING and CRITICAL scan', () => {
    const { counts } = runOf(scenario);
    assert.ok(counts.SAFE >= 1, 'SAFE');
    assert.ok(counts.WARNING >= 1, 'WARNING');
    assert.ok(counts.CRITICAL >= 1, 'CRITICAL');
  });

  test('scenario ' + scenario.id + ': at least half of the scans are SAFE, so alerts stay meaningful', () => {
    const { counts } = runOf(scenario);
    assert.ok(counts.SAFE >= 5, 'at least five of ten scans are SAFE, got ' + counts.SAFE);
    assert.ok(counts.WARNING <= 3, 'at most three warnings, got ' + counts.WARNING);
  });

  test('scenario ' + scenario.id + ': defines its own speed alert', () => {
    assert.equal(typeof scenario.speedAlertKmh, 'number');
    assert.ok(scenario.speedAlertKmh > 0);
  });

  test('scenario ' + scenario.id + ': the worst scan is CRITICAL', () => {
    const run = runOf(scenario);
    assert.equal(run.scans[run.worstIndex].status, 'CRITICAL');
  });

  test('scenario ' + scenario.id + ': better equipment never makes a scan worse, worn tires never make it better', () => {
    for (let seed = 1; seed <= 300; seed += 1) {
      const a = runOf(scenario, stock, seed);
      const b = runOf(scenario, better, seed);
      const c = runOf(scenario, worn, seed);
      a.scans.forEach((scan, i) => {
        assert.ok(engine.SEVERITY[b.scans[i].status] <= engine.SEVERITY[scan.status], 'better, seed ' + seed);
        assert.ok(engine.SEVERITY[c.scans[i].status] >= engine.SEVERITY[scan.status], 'worn, seed ' + seed);
      });
    }
  });

  test('scenario ' + scenario.id + ': the same seed with modifications compares the same sensor values', () => {
    const a = runOf(scenario, stock);
    const b = runOf(scenario, better);
    a.scans.forEach((scan, i) => {
      ['speedKmh', 'glarePct', 'distanceM', 'weather'].forEach((key) => assert.equal(b.scans[i][key], scan[key]));
    });
  });
});

test('scenarios: Highway cruise does not flag normal motorway speeds', () => {
  const sc = scenarios.getScenario('highway-cruise');
  assert.ok(sc.speedAlertKmh > 90, 'the motorway alert sits above the 90 km/h default');
  const run = runOf(sc);
  run.scans.forEach((scan) => {
    const flagged = scan.reasons.some((r) => /^Speed /.test(r));
    assert.equal(flagged, scan.speedKmh >= sc.speedAlertKmh, scan.label);
  });
  // The same samples judged with the 90 km/h default would raise extra speed warnings.
  const strict = engine.evaluateRun(generateRun(sc.seed, sc), stock);
  assert.ok(strict.counts.WARNING > run.counts.WARNING);
});

test('scenarios: Rainy city and Emergency braking use at least two weather types', () => {
  ['rainy-city', 'emergency-braking'].forEach((id) => {
    const sc = scenarios.getScenario(id);
    const types = new Set(generateRun(sc.seed, sc).map((s) => s.weather));
    assert.ok(types.size >= 2, id + ' has ' + types.size);
  });
});

test('scenarios: Emergency braking drops speed after the object appears', () => {
  const sc = scenarios.getScenario('emergency-braking');
  const run = generateRun(sc.seed, sc);
  for (let i = 6; i < run.length; i += 1) assert.ok(run[i].speedKmh < run[i - 1].speedKmh);
});

test('scenarios: modifications change the preset runs in both directions', () => {
  const rainy = scenarios.getScenario('rainy-city');
  const base = runOf(rainy, stock);
  const improved = runOf(rainy, better);
  const degraded = runOf(rainy, worn);
  const severity = (r) => r.scans.reduce((sum, s) => sum + engine.SEVERITY[s.status], 0);
  assert.ok(severity(improved) < severity(base));
  assert.ok(severity(degraded) > severity(base));
});
