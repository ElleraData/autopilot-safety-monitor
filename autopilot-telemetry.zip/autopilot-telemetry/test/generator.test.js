const test = require('node:test');
const assert = require('node:assert/strict');
const { generateRun } = require('../src/generator');
const { mulberry32, parseSeed, randomSeed, MAX_SEED } = require('../src/rng');
const scenarios = require('../src/scenarios');
const config = require('../src/config');

test('rng: the same seed gives the same sequence', () => {
  const a = mulberry32(42);
  const b = mulberry32(42);
  for (let i = 0; i < 20; i += 1) assert.equal(a(), b());
});

test('rng: values stay inside [0, 1)', () => {
  const next = mulberry32(7);
  for (let i = 0; i < 1000; i += 1) {
    const n = next();
    assert.ok(n >= 0 && n < 1);
  }
});

test('seed: parseSeed accepts integers and rejects everything else', () => {
  assert.equal(parseSeed('3732248221'), 3732248221);
  assert.equal(parseSeed(' 12 '), 12);
  assert.equal(parseSeed('0'), 0);
  assert.equal(parseSeed(String(MAX_SEED)), MAX_SEED);
  assert.equal(parseSeed(String(MAX_SEED + 1)), null);
  assert.equal(parseSeed('-5'), null);
  assert.equal(parseSeed('1.5'), null);
  assert.equal(parseSeed('abc'), null);
  assert.equal(parseSeed(''), null);
  assert.equal(parseSeed(null), null);
});

test('seed: randomSeed returns a valid seed', () => {
  assert.equal(parseSeed(randomSeed(() => 0)), 0);
  assert.equal(parseSeed(randomSeed(() => 0.999999999)), Math.floor(0.999999999 * (MAX_SEED + 1)));
});

scenarios.list.forEach((scenario) => {
  test('generator (' + scenario.id + '): the same seed reproduces the same run', () => {
    assert.deepEqual(generateRun(scenario.seed, scenario), generateRun(scenario.seed, scenario));
  });

  test('generator (' + scenario.id + '): different seeds give different runs', () => {
    assert.notDeepEqual(generateRun(1, scenario), generateRun(2, scenario));
  });

  test('generator (' + scenario.id + '): produces ' + config.scansPerRun + ' whole-number scans in range', () => {
    for (let seed = 1; seed <= 200; seed += 1) {
      const run = generateRun(seed, scenario);
      assert.equal(run.length, config.scansPerRun);
      run.forEach((s, i) => {
        assert.equal(s.index, i);
        assert.equal(s.label, 'T' + (i + 1));
        assert.ok(Number.isInteger(s.speedKmh) && s.speedKmh >= 0);
        assert.ok(Number.isInteger(s.glarePct) && s.glarePct >= 0 && s.glarePct <= 100);
        assert.ok(Number.isInteger(s.distanceM) && s.distanceM >= 5);
        assert.ok(s.weather in config.weatherGrip, 'weather ' + s.weather);
      });
    }
  });

  test('generator (' + scenario.id + '): values change smoothly between scans', () => {
    // Scripted events may jump; away from them the walk is bounded by maxStep plus the pull.
    const eventIdx = new Set((scenario.params.events || []).map((e) => e.at));
    for (let seed = 1; seed <= 100; seed += 1) {
      const run = generateRun(seed, scenario);
      for (let i = 1; i < run.length; i += 1) {
        if (eventIdx.has(i) || eventIdx.has(i - 1)) continue;
        const p = scenario.params;
        const bound = (range) => range.maxStep + 0.18 * (range.max - range.min) + 1;
        assert.ok(Math.abs(run[i].speedKmh - run[i - 1].speedKmh) <= bound(p.speed));
        assert.ok(Math.abs(run[i].glarePct - run[i - 1].glarePct) <= bound(p.glare));
      }
    }
  });
});

test('generator: scripted events land on their scan', () => {
  const emergency = scenarios.getScenario('emergency-braking');
  const run = generateRun(emergency.seed, emergency);
  assert.ok(run[5].distanceM >= 11 && run[5].distanceM <= 14);
  assert.ok(run[9].speedKmh <= 9);
});

test('generator: a scripted weather is applied', () => {
  const rainy = scenarios.getScenario('rainy-city');
  for (let seed = 1; seed <= 50; seed += 1) {
    assert.equal(generateRun(seed, rainy)[5].weather, 'Heavy Rain');
  }
});
