/*
 * scripts/bundle.js
 * Builds dist/index.html: the whole app in ONE file (styles and scripts inlined), so it can be
 * opened straight from disk, emailed, or dropped on any static host.
 *
 *   npm run build
 *
 * It reads index.html and inlines every local <link rel="stylesheet"> and <script src>.
 * External links (such as the Google Fonts stylesheet) are left alone. No dependencies.
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(ROOT, rel), 'utf8');
const isLocal = (href) => !/^([a-z]+:)?\/\//i.test(href);

function bundle(html) {
  // Stylesheets
  html = html.replace(/<link\s+rel="stylesheet"\s+href="([^"]+)"\s*\/?>/g, (tag, href) => {
    if (!isLocal(href)) return tag;
    return '<style>\n' + read(href).replace(/<\/style/gi, '<\\/style') + '\n</style>';
  });

  // Scripts: all local files are joined into one script, in page order.
  const parts = [];
  let placed = false;
  html = html.replace(/<script\s+src="([^"]+)"><\/script>\s*/g, (tag, src) => {
    if (!isLocal(src)) return tag;
    parts.push('/* ' + src + ' */\n' + read(src));
    if (placed) return '';
    placed = true;
    return '@@APP_SCRIPT@@';
  });
  const script = '<script>\n' + parts.join('\n\n').replace(/<\/script/gi, '<\\/script') + '\n</script>\n';
  return html.replace('@@APP_SCRIPT@@', () => script);
}

if (require.main === module) {
  const out = path.join(ROOT, 'dist', 'index.html');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const built = bundle(read('index.html'));
  fs.writeFileSync(out, built);
  console.log('Wrote dist/index.html (' + Math.round(built.length / 1024) + ' KB)');
}

module.exports = { bundle };
