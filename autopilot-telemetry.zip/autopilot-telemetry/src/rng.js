/*
 * rng.js
 * Seedable random numbers. The same seed always produces the same sequence,
 * which is what makes a run reproducible.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else (root.ATM = root.ATM || {}).rng = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const MAX_SEED = 4294967295; // 2^32 - 1

  /** mulberry32: small, fast PRNG. Returns a function that yields floats in [0, 1). */
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function next() {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** Parse user input into a valid seed (integer 0..2^32-1) or return null. */
  function parseSeed(value) {
    const text = String(value == null ? '' : value).trim();
    if (!/^\d{1,10}$/.test(text)) return null;
    const n = Number(text);
    return n <= MAX_SEED ? n : null;
  }

  /** A fresh random seed. Pass a custom source in tests. */
  function randomSeed(source) {
    const rand = source || Math.random;
    return Math.floor(rand() * (MAX_SEED + 1));
  }

  return { mulberry32, parseSeed, randomSeed, MAX_SEED };
});
