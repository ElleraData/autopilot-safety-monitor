/*
 * generator.js
 * Seedable generator for simulated sensor values.
 *
 * Values change smoothly from one scan to the next (a bounded random walk that
 * is pulled back toward a centre value), weather tends to persist, and a
 * scenario can script events such as an object appearing close ahead.
 * The same seed and scenario always produce the same run.
 *
 * The values are generated per scan. They are not integrated from a physical model.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./config'), require('./rng'));
  else (root.ATM = root.ATM || {}).generator = factory(root.ATM.config, root.ATM.rng);
})(typeof self !== 'undefined' ? self : this, function (config, rng) {
  'use strict';

  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

  function between(rand, range) {
    return range[0] + rand() * (range[1] - range[0]);
  }

  function pickWeighted(rand, weights) {
    const names = Object.keys(weights);
    const total = names.reduce((sum, name) => sum + weights[name], 0);
    let roll = rand() * total;
    for (let i = 0; i < names.length; i += 1) {
      roll -= weights[names[i]];
      if (roll < 0) return names[i];
    }
    return names[names.length - 1];
  }

  /** One step of a bounded random walk pulled toward a centre value. */
  function walk(rand, value, p) {
    const pull = (p.center - value) * 0.18;
    const noise = (rand() * 2 - 1) * p.maxStep;
    return clamp(value + pull + noise, p.min, p.max);
  }

  /**
   * Generate a run.
   * scenario.params: { speed, glare, distance, weather: { weights, persistence }, events }
   *   speed / glare / distance: { min, max, center, maxStep, start: [lo, hi] }
   *   events: [{ at, speedKmh?, glarePct?, distanceM?, weather? }]  (ranges are [lo, hi])
   */
  function generateRun(seed, scenario, scans) {
    const count = scans || config.scansPerRun;
    const p = scenario.params;
    const rand = rng.mulberry32(seed);

    let speed = between(rand, p.speed.start);
    let glare = between(rand, p.glare.start);
    let distance = between(rand, p.distance.start);
    let weather = pickWeighted(rand, p.weather.weights);

    const events = {};
    (p.events || []).forEach((e) => {
      events[e.at] = e;
    });

    const samples = [];
    for (let i = 0; i < count; i += 1) {
      if (i > 0) {
        speed = walk(rand, speed, p.speed);
        glare = walk(rand, glare, p.glare);
        distance = walk(rand, distance, p.distance);
        if (rand() >= p.weather.persistence) weather = pickWeighted(rand, p.weather.weights);
      }
      const event = events[i];
      if (event) {
        if (event.speedKmh) speed = between(rand, event.speedKmh);
        if (event.glarePct) glare = between(rand, event.glarePct);
        if (event.distanceM) distance = between(rand, event.distanceM);
        if (event.weather) weather = event.weather;
      }
      samples.push({
        index: i,
        label: 'T' + (i + 1),
        speedKmh: Math.round(speed),
        glarePct: Math.round(clamp(glare, 0, 100)),
        distanceM: Math.max(5, Math.round(distance)),
        weather: weather,
      });
    }
    return samples;
  }

  return { generateRun: generateRun };
});
