/*
 * config.js
 * Every threshold, vehicle parameter and modification lives here.
 * The rule engine reads these values and never hard-codes a number.
 *
 * All files in src/ (except ui/) use a small UMD wrapper so the same code
 * runs in the browser (window.ATM.*) and in Node (require) for the tests.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else (root.ATM = root.ATM || {}).config = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  return {
    gravity: 9.81, // m/s^2
    scansPerRun: 10,
    scanIntervalMs: 900, // pause between scans while a run replays

    // Alert thresholds used by the rule engine.
    thresholds: {
      ttcCriticalS: 2, // CRITICAL when time-to-collision is below this
      ttcWarningS: 4, // WARNING when time-to-collision is below this
      speedWarningKmh: 90, // WARNING at or above this speed
      glareWarningPct: 60, // WARNING at or above this camera glare
      stoppingWarningFactor: 1.5, // WARNING when the object is inside factor x stopping distance
      // WARNING when speed is above these limits in reduced-grip weather.
      lowGripSpeedKmh: { Fog: 60, 'Heavy Rain': 50 },
    },

    // Multiplier applied to tyre grip (mu) for each weather type.
    weatherGrip: { Clear: 1.0, Fog: 0.9, 'Heavy Rain': 0.6 },

    // Generic vehicle profile. Not based on any real vehicle or brand.
    profiles: {
      'ev-sedan': {
        id: 'ev-sedan',
        name: 'EV Sedan',
        mu: 0.8, // tyre grip coefficient
        brakeEfficiency: 0.9, // 0..1
        reactionTimeS: 0.5,
      },
    },

    // Toggleable simulated modifications. Each one adds a delta to the profile.
    mods: {
      performanceTires: { id: 'performanceTires', label: 'Performance tires', detail: 'grip μ +0.10', mu: 0.1 },
      upgradedBrakes: { id: 'upgradedBrakes', label: 'Upgraded brakes', detail: 'brakes +0.05 (max 1.0)', brakeEfficiency: 0.05 },
      wornTires: { id: 'wornTires', label: 'Worn tires', detail: 'grip μ −0.15', mu: -0.15 },
    },

    // Limits so combined modifications can never produce a nonsense vehicle.
    limits: { muMin: 0.1, muMax: 1.5, brakeMin: 0.1, brakeMax: 1.0 },
  };
});
