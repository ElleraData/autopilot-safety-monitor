/*
 * scenarios.js
 * Preset scenarios. Each has a fixed seed, so the first thing a visitor sees is
 * a varied run: some safe scans, some warnings, at least one critical.
 * `expectedMix` is the status count for the stock EV Sedan and is checked by the tests.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else (root.ATM = root.ATM || {}).scenarios = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const list = [
    {
      id: 'highway-cruise',
      name: 'Highway cruise',
      tagline: '85–110 km/h, mostly clear, occasional glare spikes',
      speedAlertKmh: 110, // speed rule warns at or above this speed in this scenario
      seed: 2432,
      expectedMix: { SAFE: 6, WARNING: 2, CRITICAL: 2 },
      params: {
        speed: { min: 84, max: 110, center: 94, maxStep: 7, start: [88, 98] },
        glare: { min: 8, max: 85, center: 30, maxStep: 16, start: [18, 34] },
        distance: { min: 70, max: 190, center: 125, maxStep: 30, start: [110, 160] },
        weather: { weights: { Clear: 0.8, Fog: 0.1, 'Heavy Rain': 0.1 }, persistence: 0.8 },
        events: [{ at: 6, distanceM: [38, 52] }],
      },
    },
    {
      id: 'rainy-city',
      name: 'Rainy city',
      tagline: '35–65 km/h, rain and fog, objects 10–80 m ahead',
      speedAlertKmh: 60,
      seed: 1295,
      expectedMix: { SAFE: 5, WARNING: 3, CRITICAL: 2 },
      params: {
        speed: { min: 32, max: 70, center: 50, maxStep: 8, start: [44, 56] },
        glare: { min: 8, max: 72, center: 34, maxStep: 14, start: [22, 40] },
        distance: { min: 26, max: 100, center: 62, maxStep: 20, start: [55, 80] },
        weather: { weights: { Clear: 0.2, Fog: 0.3, 'Heavy Rain': 0.5 }, persistence: 0.62 },
        events: [{ at: 5, distanceM: [10, 15], weather: 'Heavy Rain' }],
      },
    },
    {
      id: 'emergency-braking',
      name: 'Emergency braking',
      tagline: 'An object appears 12 m ahead, then the car brakes',
      speedAlertKmh: 60,
      seed: 3003,
      expectedMix: { SAFE: 7, WARNING: 1, CRITICAL: 2 },
      params: {
        speed: { min: 6, max: 72, center: 56, maxStep: 3, start: [52, 60] },
        glare: { min: 8, max: 60, center: 26, maxStep: 8, start: [16, 30] },
        distance: { min: 8, max: 110, center: 80, maxStep: 8, start: [76, 96] },
        weather: { weights: { Clear: 0.55, Fog: 0.15, 'Heavy Rain': 0.3 }, persistence: 0.75 },
        events: [
          { at: 5, speedKmh: [62, 68], distanceM: [11, 14] },
          { at: 6, speedKmh: [44, 48], distanceM: [14, 17] },
          { at: 7, speedKmh: [28, 32], distanceM: [19, 23] },
          { at: 8, speedKmh: [14, 18], distanceM: [26, 30] },
          { at: 9, speedKmh: [6, 9], distanceM: [34, 40] },
        ],
      },
    },
  ];

  const DEFAULT_ID = 'rainy-city';

  function getScenario(id) {
    return list.find((s) => s.id === id) || null;
  }

  return { list: list, DEFAULT_ID: DEFAULT_ID, getScenario: getScenario };
});
