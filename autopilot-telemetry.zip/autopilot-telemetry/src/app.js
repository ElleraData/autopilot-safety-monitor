/*
 * app.js
 * Wires the pure modules (config, engine, generator, scenarios) to the page.
 *
 * Flow: a run is 10 scans generated from a seed. The scans are revealed one by one,
 * the engine judges each one for the current vehicle, and the views redraw.
 * Changing the vehicle or a modification re-judges the same seeded sensor values.
 */
(function (root) {
  'use strict';

  const ATM = root.ATM;
  const config = ATM.config;
  const rng = ATM.rng;
  const engine = ATM.engine;
  const generator = ATM.generator;
  const scenarios = ATM.scenarios;
  const icons = ATM.icons;

  const TOTAL = config.scansPerRun;
  const T = config.thresholds;
  const TIRE_MODS = ['performanceTires', 'wornTires'];
  const SEED_ERROR = 'Enter a whole number from 0 to ' + rng.MAX_SEED + '.';

  const $ = (id) => document.getElementById(id);
  const f1 = (n) => n.toFixed(1);
  const clampPct = (n) => Math.max(0, Math.min(100, n));
  const esc = (s) =>
    String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const reduceMotion = () =>
    typeof root.matchMedia === 'function' && root.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const instant = () => /[?&]instant\b/.test(root.location.search) || reduceMotion();

  const state = {
    scenarioId: scenarios.DEFAULT_ID,
    seed: scenarios.getScenario(scenarios.DEFAULT_ID).seed,
    profileId: 'ev-sedan',
    mods: [],
    samples: [],
    stock: null,
    vehicle: null,
    run: null,
    stockRun: null,
    revealed: 0,
    selected: -1,
    follow: true,
    playing: false,
    startedAt: Date.now(),
    runId: 0,
    timer: 0,
  };

  const els = {};
  let roadView;
  let carSide;
  let charts;
  let logRunId = -1;
  let logCount = 0;

  /* ---------------------------------------------------------------- run control */

  const scenarioNow = () => scenarios.getScenario(state.scenarioId);
  /* Speed at which the speed rule warns. Each scenario sets its own (motorway vs city). */
  const speedAlert = () => engine.speedAlertKmh(scenarioNow());

  function generate() {
    const scenario = scenarioNow();
    state.samples = generator.generateRun(state.seed, scenario);
    judge();
  }

  /* Judge the same sensor values for the stock vehicle and for the current setup. */
  function judge() {
    state.stock = engine.resolveVehicle(state.profileId, []);
    state.vehicle = engine.resolveVehicle(state.profileId, state.mods);
    const scenario = scenarioNow();
    state.run = engine.evaluateRun(state.samples, state.vehicle, scenario);
    state.stockRun = engine.evaluateRun(state.samples, state.stock, scenario);
  }

  function start() {
    clearTimeout(state.timer);
    state.runId += 1;
    state.startedAt = Date.now();
    state.follow = true;
    state.selected = -1;
    state.revealed = 0;
    if (instant()) {
      state.revealed = TOTAL;
      finish();
    } else {
      state.playing = true;
      step();
      return;
    }
    renderRun();
  }

  function step() {
    state.revealed += 1;
    if (state.follow) state.selected = state.revealed - 1;
    if (state.revealed >= TOTAL) finish();
    else state.timer = setTimeout(step, config.scanIntervalMs);
    renderRun();
  }

  function finish() {
    state.playing = false;
    const run = state.run;
    if (state.follow) {
      const worst = run.scans[run.worstIndex];
      state.selected = worst.status === 'SAFE' ? TOTAL - 1 : run.worstIndex;
    }
    const c = run.counts;
    els.live.textContent = 'Run finished. ' + c.SAFE + ' safe, ' + c.WARNING + ' warnings, ' + c.CRITICAL + ' critical.';
  }

  function reset() {
    clearTimeout(state.timer);
    state.runId += 1;
    state.playing = false;
    state.revealed = 0;
    state.selected = -1;
    state.follow = true;
    els.live.textContent = 'Run cleared.';
    renderRun();
  }

  function select(i, byUser) {
    if (i < 0 || i >= state.revealed) return;
    state.selected = i;
    if (byUser) state.follow = false;
    renderSelection();
  }

  /* ---------------------------------------------------------------- control actions */

  function setScenario(id) {
    if (id === state.scenarioId || !scenarios.getScenario(id)) return;
    state.scenarioId = id;
    state.seed = scenarios.getScenario(id).seed;
    generate();
    syncControls();
    start();
  }

  function applySeed() {
    const parsed = rng.parseSeed(els.seedInput.value);
    if (parsed === null) {
      els.seedInput.setAttribute('aria-invalid', 'true');
      els.seedHint.textContent = SEED_ERROR;
      els.seedHint.dataset.error = 'true';
      return;
    }
    state.seed = parsed;
    generate();
    syncControls();
    start();
  }

  function newSeed() {
    state.seed = rng.randomSeed();
    generate();
    syncControls();
    start();
  }

  function setProfile(id) {
    state.profileId = id;
    judge();
    syncControls();
    start();
  }

  function toggleMod(id, on) {
    let note = '';
    const set = state.mods.filter((m) => m !== id);
    if (on) {
      if (TIRE_MODS.indexOf(id) !== -1) {
        const other = TIRE_MODS.filter((m) => m !== id)[0];
        if (set.indexOf(other) !== -1) note = config.mods[other].label + ' was switched off. The two tire options cannot be fitted together.';
        state.mods = set.filter((m) => m !== other).concat(id);
      } else {
        state.mods = set.concat(id);
      }
    } else {
      state.mods = set;
    }
    state.mods.sort((a, b) => Object.keys(config.mods).indexOf(a) - Object.keys(config.mods).indexOf(b));
    judge();
    syncControls(note);
    start();
  }

  /* ---------------------------------------------------------------- controls (built once, synced on change) */

  function buildControls() {
    els.scenarioGroup.innerHTML = scenarios.list
      .map((s) => '<button type="button" role="radio" class="seg__btn" data-id="' + s.id + '">' + esc(s.name) + '</button>')
      .join('');

    els.modsGroup.innerHTML = Object.keys(config.mods)
      .map((id) => {
        const m = config.mods[id];
        return (
          '<label class="mod" for="mod-' + id + '"><input type="checkbox" id="mod-' + id + '" data-mod="' + id + '">' +
          '<span class="mod__box" aria-hidden="true"></span>' +
          '<span class="mod__text"><span class="mod__name">' + esc(m.label) + '</span><span class="mod__detail">' + esc(m.detail) + '</span></span></label>'
        );
      })
      .join('');

    els.profileSelect.innerHTML = Object.keys(config.profiles)
      .map((id) => '<option value="' + id + '">' + esc(config.profiles[id].name) + '</option>')
      .join('');

    els.strip.innerHTML = Array.from({ length: TOTAL }, (_, i) => '<button type="button" class="pip" data-i="' + i + '"></button>').join('');
  }

  function syncControls(modsNote) {
    const scenario = scenarios.getScenario(state.scenarioId);
    els.scenarioGroup.querySelectorAll('.seg__btn').forEach((b) => {
      const on = b.dataset.id === state.scenarioId;
      b.setAttribute('aria-checked', on ? 'true' : 'false');
      b.tabIndex = on ? 0 : -1;
    });
    els.scenarioNote.textContent = scenario.tagline;

    els.seedInput.value = String(state.seed);
    els.seedInput.removeAttribute('aria-invalid');
    delete els.seedHint.dataset.error;
    els.seedHint.textContent =
      state.seed === scenario.seed
        ? 'Preset seed for this scenario. Use New seed to explore other runs.'
        : 'Reuse this number to get the same sensor values.';

    els.profileSelect.value = state.profileId;
    const v = state.vehicle;
    els.profileStats.textContent = 'μ ' + v.mu.toFixed(2) + ' · brakes ' + v.brakeEfficiency.toFixed(2) + ' · reaction ' + v.reactionTimeS.toFixed(2) + ' s';
    els.modsGroup.querySelectorAll('input[data-mod]').forEach((input) => {
      input.checked = state.mods.indexOf(input.dataset.mod) !== -1;
    });
    els.modsHint.textContent = modsNote || 'Changing the vehicle replays the same seeded run, so you can compare the effect.';
    els.footSeed.textContent = 'seed ' + state.seed;
    renderRules();
  }

  /* ---------------------------------------------------------------- rendering */

  function revealed() {
    return state.run.scans.slice(0, state.revealed);
  }

  function selectedScan() {
    return state.selected >= 0 && state.selected < state.revealed ? state.run.scans[state.selected] : null;
  }

  function renderRun() {
    renderTopbar();
    renderSummary();
    renderLog();
    renderSelection();
  }

  function renderTopbar() {
    const stat = state.playing ? 'running' : state.revealed === 0 ? 'idle' : 'finished';
    els.sysStat.dataset.state = stat;
    els.sysStat.textContent =
      'SYS_STAT: ' + (stat === 'running' ? 'RUNNING ' + state.revealed + '/' + TOTAL : stat.toUpperCase());
  }

  function renderSummary() {
    const counts = { SAFE: 0, WARNING: 0, CRITICAL: 0 };
    revealed().forEach((s) => {
      counts[s.status] += 1;
    });
    els.cTotal.innerHTML = state.revealed + '<span> / ' + TOTAL + '</span>';
    els.cSafe.textContent = counts.SAFE;
    els.cWarn.textContent = counts.WARNING;
    els.cCrit.textContent = counts.CRITICAL;

    els.strip.querySelectorAll('.pip').forEach((pip, i) => {
      const scan = i < state.revealed ? state.run.scans[i] : null;
      pip.className = 'pip' + (scan ? ' pip--' + scan.status.toLowerCase() : ' pip--pending');
      pip.disabled = !scan;
      pip.innerHTML = (scan ? icons.status[scan.status] : '<span class="pip__dot"></span>') + '<span class="pip__label">T' + (i + 1) + '</span>';
      pip.setAttribute('aria-label', scan ? 'T' + (i + 1) + ': ' + scan.status.toLowerCase() : 'T' + (i + 1) + ': not scanned yet');
    });
  }

  function logRow(scan) {
    const tr = document.createElement('tr');
    const status = scan.status.toLowerCase();
    const iso = new Date(state.startedAt + scan.index * 1000).toISOString();
    const extra = scan.reasons.length > 1 ? '<span class="more" title="' + esc(scan.reasons.join('\n')) + '">+' + (scan.reasons.length - 1) + '</span>' : '';
    tr.className = 'logrow logrow--' + status;
    tr.tabIndex = 0;
    tr.dataset.i = String(scan.index);
    tr.innerHTML =
      '<td class="c-time" data-label="Time"><span class="c-scan">' + scan.label + '</span>' +
      '<time datetime="' + iso + '"><span class="c-date">' + iso.slice(0, 10) + '</span> <span class="c-clock">' + iso.slice(11, 23) + ' UTC</span></time></td>' +
      '<td class="c-status" data-label="Status"><span class="badge badge--' + status + '">' + icons.status[scan.status] + scan.status + '</span></td>' +
      '<td class="c-reason" data-label="Reason">' + esc(scan.reasons[0]) + extra + '</td>' +
      '<td class="num c-speed" data-label="Speed">' + scan.speedKmh + ' km/h</td>' +
      '<td class="num c-glare" data-label="Glare">' + scan.glarePct + '%</td>' +
      '<td class="num c-dist" data-label="Object / stop"><span class="' + (scan.distanceM < scan.stoppingDistanceM ? 'is-inside' : '') + '">' + scan.distanceM + '</span> / ' + f1(scan.stoppingDistanceM) + ' m</td>' +
      '<td class="c-weather" data-label="Weather"><span class="wx">' + icons.weather[scan.weather] + esc(scan.weather) + '</span></td>';
    return tr;
  }

  /* Rows are added once per scan so keyboard focus survives while a run plays. */
  function renderLog() {
    if (logRunId !== state.runId) {
      els.logBody.textContent = '';
      logRunId = state.runId;
      logCount = 0;
    }
    for (let i = logCount; i < state.revealed; i += 1) els.logBody.prepend(logRow(state.run.scans[i]));
    logCount = state.revealed;
  }

  function renderSelection() {
    const scan = selectedScan();
    markSelected();
    renderStatus(scan);
    renderMetrics(scan);
    renderRoad(scan);
    renderCar(scan);
    renderCompare(scan);
    charts.render({ scans: revealed(), all: state.run.scans, total: TOTAL, selected: scan ? scan.index : -1, speedAlertKmh: speedAlert() });
  }

  function markSelected() {
    els.strip.querySelectorAll('.pip').forEach((pip) => {
      pip.setAttribute('aria-pressed', String(Number(pip.dataset.i) === state.selected));
    });
    els.logBody.querySelectorAll('.logrow').forEach((row) => {
      if (Number(row.dataset.i) === state.selected) row.setAttribute('aria-current', 'true');
      else row.removeAttribute('aria-current');
    });
  }

  function renderStatus(scan) {
    const panel = els.statusPanel;
    if (!scan) {
      panel.dataset.status = 'idle';
      els.statusIcon.innerHTML =
        '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><circle cx="8" cy="8" r="6.3"/><path d="M5.5 8h5"/></svg>';
      els.statusScan.textContent = 'No scan yet';
      els.statusWord.textContent = 'STANDBY';
      els.statusReasons.innerHTML = '<li class="reason reason--idle">Press Run again to replay the scans.</li>';
      return;
    }
    const worst = state.run.scans[state.run.worstIndex];
    const mostSevere = !state.playing && scan.index === state.run.worstIndex && worst.status !== 'SAFE';
    panel.dataset.status = scan.status.toLowerCase();
    els.statusIcon.innerHTML = icons.status[scan.status];
    els.statusScan.textContent = 'Scan ' + scan.label + (mostSevere ? ' · most severe in this run' : state.playing && scan.index === state.revealed - 1 ? ' · latest' : '');
    els.statusWord.textContent = scan.status;
    els.statusReasons.innerHTML = scan.reasonDetails.length
      ? scan.reasonDetails
          .map((r) => '<li class="reason reason--' + r.level.toLowerCase() + '">' + icons.status[r.level] + '<span>' + esc(r.text) + '</span></li>')
          .join('')
      : '<li class="reason reason--safe">' + icons.status.SAFE + '<span>' + esc(scan.reasons[0]) + '</span></li>';
  }

  function metricStates(scan) {
    const lowGrip = T.lowGripSpeedKmh[scan.weather];
    return {
      speed: scan.speedKmh >= speedAlert() || (lowGrip !== undefined && scan.speedKmh > lowGrip) ? 'warning' : 'ok',
      glare: scan.glarePct >= T.glareWarningPct ? 'warning' : 'ok',
      distance: scan.distanceM < scan.stoppingDistanceM ? 'critical' : scan.distanceM < scan.warnLimitM ? 'warning' : 'ok',
      ttc: scan.ttcS < T.ttcCriticalS ? 'critical' : scan.ttcS < T.ttcWarningS ? 'warning' : 'ok',
    };
  }

  function tile(o) {
    const flag = o.state && o.state !== 'ok' ? icons.status[o.state.toUpperCase()] : '';
    return (
      '<div class="metric" data-key="' + o.key + '" data-state="' + (o.state || 'ok') + '">' +
      '<div class="metric__top"><span class="metric__name">' + o.name + '</span><span class="metric__flag">' + flag + '</span></div>' +
      '<div class="metric__value"><strong>' + o.value + '</strong>' + (o.unit ? '<span>' + o.unit + '</span>' : '') + '</div>' +
      (o.pct == null
        ? ''
        : '<div class="meter"><span style="width:' + clampPct(o.pct).toFixed(1) + '%"></span>' + (o.mark != null ? '<i style="left:' + clampPct(o.mark).toFixed(1) + '%"></i>' : '') + '</div>') +
      '<p class="metric__note">' + o.note + '</p></div>'
    );
  }

  function renderMetrics(scan) {
    if (!scan) {
      const dash = [
        ['speed', 'Speed', 'km/h'],
        ['glare', 'Camera glare', '%'],
        ['distance', 'Object distance', 'm'],
        ['stop', 'Stopping distance', 'm'],
        ['ttc', 'Time to collision', 's'],
        ['env', 'Environment', ''],
      ];
      els.metrics.innerHTML = dash
        .map((d) => tile({ key: d[0], name: d[1], value: '–', unit: d[2], pct: d[0] === 'env' ? null : 0, note: 'Waiting for a scan' }))
        .join('');
      return;
    }
    const st = metricStates(scan);
    const lowGrip = T.lowGripSpeedKmh[scan.weather];
    const ttc = Number.isFinite(scan.ttcS) ? scan.ttcS.toFixed(2) : '–';
    els.metrics.innerHTML = [
      tile({
        key: 'speed', name: 'Speed', value: scan.speedKmh, unit: 'km/h', state: st.speed,
        pct: (scan.speedKmh / 130) * 100, mark: (speedAlert() / 130) * 100,
        note: 'Alert at ' + speedAlert() + ' km/h' + (lowGrip !== undefined ? ', ' + lowGrip + ' km/h in ' + scan.weather.toLowerCase() : ''),
      }),
      tile({
        key: 'glare', name: 'Camera glare', value: scan.glarePct, unit: '%', state: st.glare,
        pct: scan.glarePct, mark: T.glareWarningPct, note: 'Alert at ' + T.glareWarningPct + '%',
      }),
      tile({
        key: 'distance', name: 'Object distance', value: scan.distanceM, unit: 'm', state: st.distance,
        pct: (scan.distanceM / 200) * 100, mark: (scan.stoppingDistanceM / 200) * 100,
        note: scan.distanceM < scan.stoppingDistanceM ? 'Inside the ' + f1(scan.stoppingDistanceM) + ' m stopping distance' : 'Stopping distance ' + f1(scan.stoppingDistanceM) + ' m',
      }),
      tile({
        key: 'stop', name: 'Stopping distance', value: f1(scan.stoppingDistanceM), unit: 'm', state: 'ok',
        pct: (scan.stoppingDistanceM / 200) * 100,
        note: 'Reaction ' + f1(scan.reactionM) + ' m + braking ' + f1(scan.brakingM) + ' m',
      }),
      tile({
        key: 'ttc', name: 'Time to collision', value: ttc, unit: 's', state: st.ttc,
        pct: Number.isFinite(scan.ttcS) ? (scan.ttcS / 8) * 100 : 100, mark: (T.ttcWarningS / 8) * 100,
        note: Number.isFinite(scan.ttcS) ? 'Warning below ' + T.ttcWarningS + ' s, critical below ' + T.ttcCriticalS + ' s' : 'The vehicle is stopped',
      }),
      tile({
        key: 'env', name: 'Environment', value: esc(scan.weather), unit: '', state: 'ok',
        note: 'Tyre grip ×' + engine.gripFactor(scan.weather).toFixed(2),
      }).replace('<span class="metric__flag"></span>', '<span class="metric__flag metric__flag--wx">' + icons.weather[scan.weather] + '</span>'),
    ].join('');
  }

  function renderRoad(scan) {
    const svg = els.roadView;
    if (!scan) {
      svg.dataset.idle = 'true';
      roadView.update({
        speedKmh: 0, glarePct: 0, distanceM: 60, weather: 'Clear', status: 'SAFE',
        reactionM: 0, stopM: 0, warnM: 0, vehicle: state.vehicle, playing: false,
      });
      return;
    }
    svg.dataset.idle = 'false';
    roadView.update({
      speedKmh: scan.speedKmh, glarePct: scan.glarePct, distanceM: scan.distanceM, weather: scan.weather, status: scan.status,
      reactionM: scan.reactionM, stopM: scan.stoppingDistanceM, warnM: scan.warnLimitM, vehicle: state.vehicle, playing: state.playing,
    });
  }

  function renderCar(scan) {
    carSide.update({
      status: scan ? scan.status : null,
      mods: state.vehicle.mods,
      weather: scan ? scan.weather : 'Clear',
      speedKmh: scan ? scan.speedKmh : 0,
      playing: state.playing,
    });
  }

  function countsOf(scans) {
    const c = { SAFE: 0, WARNING: 0, CRITICAL: 0 };
    scans.forEach((s) => {
      c[s.status] += 1;
    });
    return c;
  }

  function renderCompare(scan) {
    if (!scan) {
      els.cmpBody.innerHTML = '<p class="cmp__empty">Run the scans to compare the stock vehicle with your setup.</p>';
      return;
    }
    const stockScan = state.stockRun.scans[scan.index];
    const a = stockScan.stoppingDistanceM;
    const b = scan.stoppingDistanceM;
    const scale = Math.max(a, b, scan.distanceM) * 1.08;
    const pos = (m) => ((m / scale) * 100).toFixed(1);
    const modNames = state.vehicle.mods.map((id) => config.mods[id].label);
    const setupName = modNames.length ? state.vehicle.name + ' + ' + modNames.join(' + ').toLowerCase() : state.vehicle.name + ' (no modifications)';
    const delta = b - a;
    let deltaText;
    if (Math.abs(delta) < 0.05) deltaText = modNames.length ? 'Same stopping distance in this scan.' : 'Turn on a modification to compare it with the stock vehicle.';
    else deltaText = f1(Math.abs(delta)) + ' m ' + (delta < 0 ? 'shorter' : 'longer') + ' (' + (delta < 0 ? '−' : '+') + Math.abs((delta / a) * 100).toFixed(0) + '%) than stock.';

    const row = (name, stop, cls) =>
      '<div class="cmp__row ' + cls + '"><div class="cmp__label"><span class="cmp__name">' + esc(name) + '</span><strong class="cmp__val">' + f1(stop) + ' m</strong></div>' +
      (scan.distanceM < stop ? '<span class="cmp__flag">Would still reach the object</span>' : '') +
      '<div class="cmp__bar" role="img" aria-label="' + esc(name) + ' stops in ' + f1(stop) + ' metres, object at ' + scan.distanceM + ' metres">' +
      '<span class="cmp__fill' + (scan.distanceM < stop ? ' is-over' : '') + '" style="width:' + pos(stop) + '%"></span>' +
      '<i class="cmp__obj" style="left:' + pos(scan.distanceM) + '%"></i></div></div>';

    const ca = countsOf(state.stockRun.scans.slice(0, state.revealed));
    const cb = countsOf(revealed());
    const runLine = (name, c) =>
      '<tr><th scope="row">' + esc(name) + '</th><td>' + c.SAFE + '</td><td>' + c.WARNING + '</td><td>' + c.CRITICAL + '</td></tr>';

    const hasMods = state.vehicle.mods.length > 0;
    const intro = '<p class="cmp__scan">Scan ' + scan.label + ' · ' + esc(scan.weather) + ' · ' + scan.speedKmh + ' km/h · object at ' + scan.distanceM + ' m</p>';
    const legend = '<p class="cmp__legend"><i class="cmp__key cmp__key--obj"></i>Object distance. A bar that passes the mark would not stop in time.</p>';

    if (!hasMods) {
      // Nothing to compare yet: show the stock vehicle once instead of two identical bars.
      els.cmpBody.innerHTML =
        intro +
        row('Stock ' + state.stock.name, a, 'cmp__row--stock') +
        legend +
        '<p class="cmp__delta" data-dir="same">Turn on a modification to compare it with the stock vehicle.</p>';
      return;
    }

    els.cmpBody.innerHTML =
      intro +
      row('Stock ' + state.stock.name, a, 'cmp__row--stock') +
      row(setupName, b, 'cmp__row--setup') +
      legend +
      '<p class="cmp__delta" data-dir="' + (Math.abs(delta) < 0.05 ? 'same' : delta < 0 ? 'better' : 'worse') + '">' + deltaText + '</p>' +
      '<table class="cmp__runtable"><caption>Whole run, same seed (' + state.seed + ')</caption>' +
      '<thead><tr><th scope="col"><span class="sr-only">Vehicle</span></th><th scope="col">Safe</th><th scope="col">Warning</th><th scope="col">Critical</th></tr></thead><tbody>' +
      runLine('Stock', ca) + runLine('Your setup', cb) + '</tbody></table>';
  }

  function renderRules() {
    const scenario = scenarioNow();
    const rows = [
      ['CRITICAL', 'Time to collision', 'below ' + T.ttcCriticalS + ' s'],
      ['CRITICAL', 'Object distance', 'closer than the stopping distance'],
      ['WARNING', 'Time to collision', 'below ' + T.ttcWarningS + ' s'],
      ['WARNING', 'Object distance', 'inside ' + T.stoppingWarningFactor + '× the stopping distance'],
      ['WARNING', 'Speed', 'at or above ' + speedAlert() + ' km/h (' + scenario.name + ')'],
      ['WARNING', 'Camera glare', 'at or above ' + T.glareWarningPct + '%'],
    ].concat(Object.keys(T.lowGripSpeedKmh).map((w) => ['WARNING', 'Speed in ' + w.toLowerCase(), 'above ' + T.lowGripSpeedKmh[w] + ' km/h']));
    rows.push(['SAFE', 'Everything else', 'no rule fired']);
    $('ruleTable').innerHTML =
      '<thead><tr><th scope="col">Level</th><th scope="col">Rule</th><th scope="col">Triggers when</th></tr></thead><tbody>' +
      rows
        .map((r) => '<tr><td><span class="badge badge--' + r[0].toLowerCase() + '">' + icons.status[r[0]] + r[0] + '</span></td><td>' + esc(r[1]) + '</td><td>' + esc(r[2]) + '</td></tr>')
        .join('') +
      '</tbody>';

    // notes that do not change with the scenario are added once
    if (!document.getElementById('ruleNoteWeather')) {
      const grip = Object.keys(config.weatherGrip).map((w) => w + ' ×' + config.weatherGrip[w].toFixed(1)).join(', ');
      const alerts = scenarios.list.map((sc) => sc.name + ' ' + engine.speedAlertKmh(sc) + ' km/h').join(', ');
      const notes = document.querySelector('.rules__notes');
      const second = document.createElement('li');
      second.id = 'ruleNoteSpeed';
      second.textContent = 'Each scenario sets its own speed alert, so a motorway is not judged by a city limit: ' + alerts + '.';
      const first = document.createElement('li');
      first.id = 'ruleNoteWeather';
      first.textContent = 'Weather multiplies tyre grip: ' + grip + '.';
      notes.prepend(first, second);
    }
  }

  /* ---------------------------------------------------------------- events and boot */

  function bind() {
    els.scenarioGroup.addEventListener('click', (e) => {
      const b = e.target.closest('[data-id]');
      if (b) setScenario(b.dataset.id);
    });
    els.scenarioGroup.addEventListener('keydown', (e) => {
      const dir = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 0;
      if (!dir) return;
      e.preventDefault();
      const ids = scenarios.list.map((s) => s.id);
      const next = ids[(ids.indexOf(state.scenarioId) + dir + ids.length) % ids.length];
      setScenario(next);
      els.scenarioGroup.querySelector('[data-id="' + next + '"]').focus();
    });
    els.seedApply.addEventListener('click', applySeed);
    els.seedNew.addEventListener('click', newSeed);
    els.seedInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        applySeed();
      }
    });
    els.profileSelect.addEventListener('change', () => setProfile(els.profileSelect.value));
    els.modsGroup.addEventListener('change', (e) => {
      const input = e.target.closest('input[data-mod]');
      if (input) toggleMod(input.dataset.mod, input.checked);
    });
    els.runAgain.addEventListener('click', start);
    els.reset.addEventListener('click', reset);
    els.strip.addEventListener('click', (e) => {
      const pip = e.target.closest('.pip');
      if (pip) select(Number(pip.dataset.i), true);
    });
    els.logBody.addEventListener('click', (e) => {
      const row = e.target.closest('.logrow');
      if (row) select(Number(row.dataset.i), true);
    });
    els.logBody.addEventListener('keydown', (e) => {
      const row = e.target.closest('.logrow');
      if (!row) return;
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        select(Number(row.dataset.i), true);
      } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const next = e.key === 'ArrowDown' ? row.nextElementSibling : row.previousElementSibling;
        if (next) next.focus();
      }
    });
  }

  /* Theme: black and gold by default, ivory and gold on request. The choice is remembered in the browser. */
  function initTheme() {
    const html = document.documentElement;
    const button = $('themeToggle');
    const KEY = 'atm-theme';
    function apply(theme) {
      if (theme === 'light') html.setAttribute('data-theme', 'light');
      else html.removeAttribute('data-theme');
      if (button) button.textContent = theme === 'light' ? 'Black theme' : 'Ivory theme';
    }
    let saved = null;
    try {
      saved = root.localStorage.getItem(KEY);
    } catch (e) {
      /* storage can be blocked; the page still works */
    }
    apply(saved === 'light' ? 'light' : 'dark');
    if (button) {
      button.addEventListener('click', () => {
        const next = html.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
        apply(next);
        try {
          root.localStorage.setItem(KEY, next);
        } catch (e) {
          /* ignore */
        }
      });
    }
  }

  function init() {
    initTheme();
    [
      'sysStat', 'runAgain', 'reset', 'scenarioGroup', 'scenarioNote', 'seedInput', 'seedApply', 'seedNew', 'seedHint',
      'profileSelect', 'profileStats', 'modsGroup', 'modsHint', 'cTotal', 'cSafe', 'cWarn', 'cCrit', 'strip', 'roadView',
      'statusPanel', 'statusIcon', 'statusScan', 'statusWord', 'statusReasons', 'metrics', 'cmpBody', 'charts', 'logBody',
      'footSeed',
    ].forEach((id) => {
      els[id] = $(id);
    });
    els.live = $('liveMsg');

    roadView = ATM.roadView.create(els.roadView);
    carSide = ATM.carSide.create($('carSide'));
    charts = ATM.charts.create(els.charts, { onSelect: (i) => select(i, true) });

    buildControls();
    generate();
    syncControls();
    bind();
    start();
  }

  ATM.app = { state: state, start: start, reset: reset, select: select };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})(window);
