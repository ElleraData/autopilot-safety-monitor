/*
 * charts.js
 * Two small line charts that share one X axis (scan T1..T10): speed and camera glare.
 * They have different units, so each gets its own Y axis instead of sharing a dual axis.
 * Hovering or focusing a scan shows one tooltip and a crosshair on both charts.
 */
(function (root) {
  'use strict';

  const ATM = root.ATM;
  const config = ATM.config;

  const PAD = { left: 48, right: 20, top: 14 };
  const SVG_NS = 'http://www.w3.org/2000/svg';

  const DEFS = [
    {
      key: 'speedKmh',
      title: 'Speed',
      unit: 'km/h',
      max: 120,
      step: 30,
      color: 'var(--series-speed)',
      ref: { value: config.thresholds.speedWarningKmh, label: 'Alert at ' + config.thresholds.speedWarningKmh + ' km/h' },
      height: 150,
      bottom: 12,
    },
    {
      key: 'glarePct',
      title: 'Camera glare',
      unit: '%',
      max: 100,
      step: 20,
      color: 'var(--series-glare)',
      ref: { value: config.thresholds.glareWarningPct, label: 'Alert at ' + config.thresholds.glareWarningPct + '%' },
      height: 178,
      bottom: 40,
    },
  ];

  function el(name, attrs, text) {
    const node = document.createElementNS(SVG_NS, name);
    Object.keys(attrs || {}).forEach((k) => node.setAttribute(k, attrs[k]));
    if (text !== undefined) node.textContent = text;
    return node;
  }

  /* True when the polyline through pts passes through the box [x0,x1] x [y0,y1] (marker radius included). */
  function crossesBox(pts, x0, x1, y0, y1) {
    for (let i = 0; i < pts.length; i += 1) {
      const a = pts[i];
      const b = pts[i + 1] || a;
      const lo = Math.max(x0, Math.min(a[0], b[0]));
      const hi = Math.min(x1, Math.max(a[0], b[0]));
      if (lo > hi) continue;
      const at = (x) => (b[0] === a[0] ? a[1] : a[1] + ((b[1] - a[1]) * (x - a[0])) / (b[0] - a[0]));
      const top = Math.min(at(lo), at(hi)) - 5;
      const bottom = Math.max(at(lo), at(hi)) + 5;
      if (bottom >= y0 && top <= y1) return true;
    }
    return false;
  }

  /*
   * Where to write the alert label. It prefers above the line on the right, then above on the
   * left, then below on the right and left, and takes the first spot the data line does not cross.
   */
  function placeRefLabel(pts, lineY, width, avoidX) {
    const LABEL_W = 118;
    const right = width - PAD.right - 4;
    const left = PAD.left + 4;
    const spots = [
      { x: right, anchor: 'end', y: lineY - 6, box: [right - LABEL_W, right, lineY - 19, lineY - 1] },
      { x: left, anchor: 'start', y: lineY - 6, box: [left, left + LABEL_W, lineY - 19, lineY - 1] },
      { x: right, anchor: 'end', y: lineY + 16, box: [right - LABEL_W, right, lineY + 3, lineY + 21] },
      { x: left, anchor: 'start', y: lineY + 16, box: [left, left + LABEL_W, lineY + 3, lineY + 21] },
    ];
    // the selected-scan crosshair is a vertical line, so a label it would strike through is skipped too
    const struck = (s) => typeof avoidX === 'number' && avoidX >= s.box[0] - 2 && avoidX <= s.box[1] + 2;
    const free = spots.find((s) => !struck(s) && !crossesBox(pts, s.box[0], s.box[1], s.box[2], s.box[3]));
    return free || spots.find((s) => !struck(s)) || spots[0];
  }

  function create(host, handlers) {
    host.textContent = '';
    const cards = DEFS.map(function (def) {
      const wrap = document.createElement('figure');
      wrap.className = 'chart';
      const cap = document.createElement('figcaption');
      cap.className = 'chart__title';
      const name = document.createElement('span');
      name.textContent = def.title;
      const unit = document.createElement('span');
      unit.className = 'chart__unit';
      unit.textContent = def.unit;
      cap.append(name, unit);
      const svg = el('svg', { class: 'chart__svg', role: 'group', 'aria-label': def.title + ' by scan' });
      wrap.append(cap, svg);
      host.append(wrap);
      return { def: def, wrap: wrap, svg: svg };
    });

    const tip = document.createElement('div');
    tip.className = 'tip';
    tip.hidden = true;
    tip.setAttribute('role', 'presentation');
    host.append(tip);

    let last = null; // last render arguments, reused on resize
    let hoverIndex = -1;

    function showTip(index, cx, wrapEl) {
      const scan = last && last.scans[index];
      if (!scan) return hideTip();
      tip.textContent = '';
      const head = document.createElement('div');
      head.className = 'tip__head';
      const badge = document.createElement('span');
      badge.className = 'badge badge--' + scan.status.toLowerCase();
      badge.innerHTML = ATM.icons.status[scan.status];
      badge.append(document.createTextNode(scan.status));
      const label = document.createElement('span');
      label.className = 'tip__scan';
      label.textContent = scan.label;
      head.append(label, badge);
      tip.append(head);

      [
        ['var(--series-speed)', scan.speedKmh + ' km/h', 'Speed'],
        ['var(--series-glare)', scan.glarePct + '%', 'Camera glare'],
      ].forEach(function (r) {
        const row = document.createElement('div');
        row.className = 'tip__row';
        const key = document.createElement('span');
        key.className = 'tip__key';
        key.style.background = r[0];
        const val = document.createElement('strong');
        val.textContent = r[1];
        const nm = document.createElement('span');
        nm.className = 'tip__name';
        nm.textContent = r[2];
        row.append(key, val, nm);
        tip.append(row);
      });
      const extra = document.createElement('div');
      extra.className = 'tip__extra';
      extra.textContent = 'Object ' + scan.distanceM + ' m · stop ' + scan.stoppingDistanceM.toFixed(1) + ' m · ' + scan.weather;
      tip.append(extra);

      tip.hidden = false;
      const hostBox = host.getBoundingClientRect();
      const wrapBox = wrapEl.getBoundingClientRect();
      const tipW = tip.offsetWidth;
      let left = wrapBox.left - hostBox.left + cx + 16;
      if (left + tipW > hostBox.width - 4) left = wrapBox.left - hostBox.left + cx - tipW - 16;
      tip.style.left = Math.max(4, left) + 'px';
      tip.style.top = wrapBox.top - hostBox.top + 28 + 'px';
    }

    function hideTip() {
      tip.hidden = true;
    }

    function setHover(index, cx, wrapEl) {
      hoverIndex = index;
      moveHoverLines();
      if (index >= 0) showTip(index, cx, wrapEl);
      else hideTip();
    }

    /* Move the light crosshair on both charts without rebuilding them (rebuilding would drop pointer and focus). */
    function moveHoverLines() {
      cards.forEach(function (card) {
        if (!card.hoverLine) return;
        const show = hoverIndex >= 0 && last && hoverIndex < last.scans.length && hoverIndex !== last.selected;
        card.hoverLine.style.visibility = show ? 'visible' : 'hidden';
        if (show) {
          const cx = card.xOf(hoverIndex);
          card.hoverLine.setAttribute('x1', cx);
          card.hoverLine.setAttribute('x2', cx);
        }
      });
    }

    function draw() {
      if (!last) return;
      const scans = last.scans;
      const total = last.total;
      const selected = last.selected;
      const width = Math.max(280, host.clientWidth);

      // remember which column has keyboard focus so a rebuild does not lose it
      const active = document.activeElement;
      const focusKey =
        active && active.classList && active.classList.contains('g-hit') && host.contains(active)
          ? { chart: active.getAttribute('data-chart'), i: Number(active.getAttribute('data-i')) }
          : null;

      cards.forEach(function (card) {
        const def = card.def;
        const svg = card.svg;
        const H = def.height;
        const plotW = width - PAD.left - PAD.right;
        const plotH = H - PAD.top - def.bottom;
        const band = plotW / total;
        const x = (i) => PAD.left + band * (i + 0.5);
        const y = (v) => PAD.top + plotH * (1 - v / def.max);

        svg.textContent = '';
        svg.setAttribute('viewBox', '0 0 ' + width + ' ' + H);
        svg.setAttribute('width', width);
        svg.setAttribute('height', H);

        // grid and Y ticks
        for (let t = 0; t <= def.max; t += def.step) {
          svg.append(el('line', { class: 'g-grid', x1: PAD.left, x2: width - PAD.right, y1: y(t), y2: y(t) }));
          svg.append(el('text', { class: 'g-tick', x: PAD.left - 10, y: y(t) + 4, 'text-anchor': 'end' }, String(t)));
        }

        // X labels on the bottom chart only (both share the same columns)
        if (def.bottom > 20) {
          for (let i = 0; i < total; i += 1) {
            const s = scans[i];
            const cls = 'g-xlabel' + (i === selected ? ' is-selected' : '') + (s ? '' : ' is-pending');
            svg.append(el('text', { class: cls, x: x(i), y: H - def.bottom + 22, 'text-anchor': 'middle' }, 'T' + (i + 1)));
          }
        }

        // alert threshold (the speed alert is set per scenario)
        const ref =
          def.key === 'speedKmh' && typeof last.speedAlertKmh === 'number'
            ? { value: last.speedAlertKmh, label: 'Alert at ' + last.speedAlertKmh + ' km/h' }
            : def.ref;
        svg.append(el('line', { class: 'g-ref', x1: PAD.left, x2: width - PAD.right, y1: y(ref.value), y2: y(ref.value) }));
        // place the label against the whole run, so it does not jump sides while scans arrive
        const fullRun = (last.all || scans).map((s, i) => [x(i), y(s[def.key])]);
        const spot = placeRefLabel(fullRun, y(ref.value), width, selected >= 0 && selected < scans.length ? x(selected) : undefined);
        svg.append(el('text', { class: 'g-reflabel', x: spot.x, y: spot.y, 'text-anchor': spot.anchor }, ref.label));

        // crosshairs: the selected scan (solid) and, separately, the hovered scan (lighter)
        if (selected >= 0 && selected < scans.length) {
          svg.append(el('line', { class: 'g-cross is-selected', x1: x(selected), x2: x(selected), y1: PAD.top, y2: PAD.top + plotH }));
        }
        card.hoverLine = el('line', { class: 'g-cross', x1: 0, x2: 0, y1: PAD.top, y2: PAD.top + plotH });
        card.hoverLine.style.visibility = 'hidden';
        card.xOf = x;
        svg.append(card.hoverLine);

        // series: area wash, line, markers
        if (scans.length) {
          const pts = scans.map((s, i) => [x(i), y(s[def.key])]);
          const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('');
          const base = PAD.top + plotH;
          svg.append(
            el('path', {
              class: 'g-area',
              d: line + 'L' + pts[pts.length - 1][0].toFixed(1) + ' ' + base + 'L' + pts[0][0].toFixed(1) + ' ' + base + 'Z',
              style: 'fill:' + def.color,
            })
          );
          svg.append(el('path', { class: 'g-line', d: line, style: 'stroke:' + def.color }));
          pts.forEach(function (p, i) {
            const isSel = i === selected;
            svg.append(
              el('circle', { class: 'g-dot' + (isSel ? ' is-selected' : ''), cx: p[0], cy: p[1], r: isSel ? 6 : 4.5, style: 'fill:' + def.color })
            );
          });
          // label only the selected point
          if (selected >= 0 && selected < pts.length) {
            const sel = pts[selected];
            const value = scans[selected][def.key] + (def.unit === '%' ? '%' : '');
            const above = sel[1] - PAD.top > 26;
            svg.append(
              el('text', { class: 'g-value', x: sel[0], y: above ? sel[1] - 13 : sel[1] + 22, 'text-anchor': 'middle' }, value)
            );
          }
        }

        // hit columns: pointer, focus, click and keyboard
        for (let i = 0; i < total; i += 1) {
          const s = scans[i];
          if (!s) continue;
          const col = el('rect', {
            class: 'g-hit',
            x: x(i) - band / 2,
            y: PAD.top - 6,
            width: band,
            height: plotH + 12,
            tabindex: 0,
            role: 'button',
            'data-chart': def.key,
            'data-i': i,
            'aria-label':
              s.label + ': ' + s.status.toLowerCase() + ', speed ' + s.speedKmh + ' km/h, glare ' + s.glarePct + '%, object ' + s.distanceM + ' m',
          });
          const cx = x(i);
          col.addEventListener('pointerenter', () => setHover(i, cx, card.wrap));
          col.addEventListener('pointermove', () => {
            if (hoverIndex !== i) setHover(i, cx, card.wrap);
          });
          col.addEventListener('pointerleave', () => setHover(-1, 0, card.wrap));
          col.addEventListener('focus', () => setHover(i, cx, card.wrap));
          col.addEventListener('blur', () => setHover(-1, 0, card.wrap));
          col.addEventListener('click', () => handlers.onSelect(i));
          col.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handlers.onSelect(i);
            } else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
              e.preventDefault();
              const hits = svg.querySelectorAll('.g-hit');
              const next = hits[i + (e.key === 'ArrowRight' ? 1 : -1)];
              if (next) next.focus();
            }
          });
          svg.append(col);
        }
      });

      if (focusKey) {
        const again = host.querySelector('.g-hit[data-chart="' + focusKey.chart + '"][data-i="' + focusKey.i + '"]');
        if (again) again.focus({ preventScroll: true });
      }
      moveHoverLines();
    }

    /** scans: revealed scans (evaluated). total: scans per run. selected: index or -1. */
    function render(args) {
      last = args;
      if (hoverIndex >= args.scans.length) hoverIndex = -1;
      draw();
    }

    if (typeof ResizeObserver === 'function') {
      let w = host.clientWidth;
      new ResizeObserver(function () {
        if (host.clientWidth !== w) {
          w = host.clientWidth;
          hideTip();
          hoverIndex = -1;
          draw();
        }
      }).observe(host);
    }

    return { render: render };
  }

  ATM.charts = { create: create };
})(window);
