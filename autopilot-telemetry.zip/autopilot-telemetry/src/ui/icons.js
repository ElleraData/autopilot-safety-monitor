/*
 * icons.js
 * Small inline SVG icons. Status is always shown as icon + word, never colour alone.
 * Shapes differ per status: circle (safe), triangle (warning), octagon (critical).
 */
(function (root) {
  'use strict';

  const attrs =
    'viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"';
  const svg = (inner) => '<svg ' + attrs + '>' + inner + '</svg>';

  const status = {
    SAFE: svg('<circle cx="8" cy="8" r="6.3"/><path d="M5.2 8.4l2 2 3.6-4.3"/>'),
    WARNING: svg('<path d="M8 2.3l6.2 10.9H1.8z"/><path d="M8 6.5v3"/><path d="M8 11.3v.1"/>'),
    CRITICAL: svg('<path d="M5.3 1.9h5.4l3.4 3.4v5.4l-3.4 3.4H5.3l-3.4-3.4V5.3z"/><path d="M8 4.8v3.6"/><path d="M8 10.8v.1"/>'),
  };

  const weather = {
    Clear: svg(
      '<circle cx="8" cy="8" r="2.8"/><path d="M8 1.6v1.6M8 12.8v1.6M1.6 8h1.6M12.8 8h1.6M3.5 3.5l1.1 1.1M11.4 11.4l1.1 1.1M3.5 12.5l1.1-1.1M11.4 4.6l1.1-1.1"/>'
    ),
    Fog: svg('<path d="M2 4.5h9M4.5 8h9.5M2 11.5h7M11 11.5h3"/>'),
    'Heavy Rain': svg(
      '<path d="M4.6 9.4a3 3 0 0 1 .4-5.9 4 4 0 0 1 7.5 1.2A2.4 2.4 0 0 1 12 9.4z"/><path d="M5 11.4l-.8 2.2M8.2 11.4l-.8 2.2M11.4 11.4l-.8 2.2"/>'
    ),
  };

  (root.ATM = root.ATM || {}).icons = { status: status, weather: weather };
})(window);
