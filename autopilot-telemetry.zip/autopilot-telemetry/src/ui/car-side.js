/*
 * car-side.js
 * Side view of a generic EV sedan. It is an original drawing: a low nose, a long raked
 * windscreen that flows into one roof arc, a short fastback tail, flush door handles and
 * slim lamps. It does not copy any real vehicle and carries no badge, logo or brand name.
 *
 * The drawing reacts to the run:
 *   - the glow under the car takes the status colour (safe / warning / critical)
 *   - tail lamps flare while the status is CRITICAL (braking)
 *   - modifications show on the wheels: performance tires, red calipers, worn tires
 *   - the wheels turn slowly while a run is playing
 *   - headlight beams appear in fog and rain
 */
(function (root) {
  'use strict';

  const W = 470;
  const VIEW_Y = 14;
  const VIEW_H = 156;
  const GROUND = 142;
  const WHEEL_R = 28;
  const WHEEL_Y = GROUND - WHEEL_R;
  const REAR_X = 121;
  const FRONT_X = 351;
  const ARCH_R = 32;
  const SILL_Y = 128;

  // Wheel arches are cut out of the silhouette with arcs.
  const archDx = Math.sqrt(ARCH_R * ARCH_R - Math.pow(SILL_Y - WHEEL_Y, 2));
  const fa = [(FRONT_X + archDx).toFixed(1), (FRONT_X - archDx).toFixed(1)];
  const ra = [(REAR_X + archDx).toFixed(1), (REAR_X - archDx).toFixed(1)];

  const BODY =
    'M66 ' + SILL_Y +
    'C56 127.5 48.5 120 46.8 106C45.8 96 46.2 90 47.8 82C49 75 51 71 56 68.4' +
    'C66 65.6 88 62.6 112 60.4' + // trunk lid
    'C134 52 164 36 200 28.2' + // fastback glass
    'C220 25.8 244 25.4 262 26.4' + // roof
    'C286 28 306 42 332 61.5' + // windscreen
    'C360 65 392 73.5 410 81.5' + // bonnet
    'C419 85.5 424.6 92 425 100' + // nose
    'C425.3 111 422 120 415 124.4C411 127 406 ' + SILL_Y + ' 400 ' + SILL_Y +
    'L' + fa[0] + ' ' + SILL_Y + 'A' + ARCH_R + ' ' + ARCH_R + ' 0 1 0 ' + fa[1] + ' ' + SILL_Y +
    'L' + ra[0] + ' ' + SILL_Y + 'A' + ARCH_R + ' ' + ARCH_R + ' 0 1 0 ' + ra[1] + ' ' + SILL_Y +
    'L66 ' + SILL_Y + 'Z';

  // Glass: rear window and front window, split by a dark B pillar.
  const GLASS_REAR = 'M126 60.4C144 53.5 170 39.5 199 31.8L206 31.4L206 60.4Z';
  const GLASS_FRONT = 'M214.4 60.4L213.6 31C229 29.8 246 29.6 261 30.4C281 32 301 44 322.5 60.4Z';

  function polar(r, deg) {
    const a = (deg * Math.PI) / 180;
    return [r * Math.cos(a), r * Math.sin(a)];
  }

  // A slot between two angles and two radii, used for the wheel openings.
  function slot(r0, r1, a0, a1) {
    const p = (r, a) => polar(r, a).map((n) => n.toFixed(2)).join(' ');
    return 'M' + p(r0, a0) + 'L' + p(r1, a0) + 'A' + r1 + ' ' + r1 + ' 0 0 1 ' + p(r1, a1) + 'L' + p(r0, a1) + 'A' + r0 + ' ' + r0 + ' 0 0 0 ' + p(r0, a0) + 'Z';
  }

  // The rim is one path: a disc with five openings cut out (even-odd), so the brake disc
  // and caliper show through the openings.
  const RIM_R = 20;
  const RIM_PATH = (function () {
    let d = 'M-' + RIM_R + ' 0A' + RIM_R + ' ' + RIM_R + ' 0 1 0 ' + RIM_R + ' 0A' + RIM_R + ' ' + RIM_R + ' 0 1 0 -' + RIM_R + ' 0Z';
    for (let i = 0; i < 5; i += 1) d += slot(9.8, 17.4, i * 72 + 9, i * 72 + 51);
    return d;
  })();

  function wheelMarkup(cx) {
    return (
      '<g class="wheelg" transform="translate(' + cx + ' ' + WHEEL_Y + ')">' +
      '<circle class="tire" r="' + WHEEL_R + '"/>' +
      '<circle class="tire-wall" r="24.8"/>' +
      '<circle class="tire-wear" r="26.4"/>' +
      '<circle class="disc" r="18"/>' +
      '<path class="caliper" d="M-3.4 -15.2A15.6 15.6 0 0 1 13.2 -8.2"/>' +
      '<g class="rimg">' +
      '<path class="rim-face" fill-rule="evenodd" d="' + RIM_PATH + '"/>' +
      '<path class="rim-sheen" fill-rule="evenodd" d="' + RIM_PATH + '"/>' +
      '<circle class="rim-lip" r="' + RIM_R + '"/>' +
      '<circle class="hub" r="4.4"/>' +
      '</g>' +
      '</g>'
    );
  }

  function markup() {
    const cx = W / 2;
    return (
      '<defs>' +
      // paint: shoulder highlight, a dark horizon reflection, a lighter bounce near the sill
      '<linearGradient id="sbBody" x1="0" x2="0" y1="0" y2="1">' +
      '<stop offset="0" style="stop-color:var(--car-hi)"/><stop offset=".2" style="stop-color:var(--car-hi)"/>' +
      '<stop offset=".34" style="stop-color:var(--car-mid)"/><stop offset=".47" style="stop-color:var(--car-horizon)"/>' +
      '<stop offset=".62" style="stop-color:var(--car-mid)"/><stop offset=".86" style="stop-color:var(--car-lo)"/>' +
      '<stop offset="1" style="stop-color:var(--car-lo)"/></linearGradient>' +
      '<linearGradient id="sbSheen" x1="0" x2="1" y1="0" y2="0">' +
      '<stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".26" stop-color="#fff" stop-opacity=".2"/>' +
      '<stop offset=".48" stop-color="#fff" stop-opacity="0"/><stop offset=".78" stop-color="#fff" stop-opacity=".12"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>' +
      '<linearGradient id="sbRocker" x1="0" x2="0" y1="0" y2="1">' +
      '<stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".55"/></linearGradient>' +
      '<linearGradient id="sbGlass" x1="0" x2="0" y1="0" y2="1">' +
      '<stop offset="0" style="stop-color:var(--car-glass-hi)"/><stop offset="1" style="stop-color:var(--car-glass-lo)"/></linearGradient>' +
      '<linearGradient id="sbReflect" x1="0" x2="1" y1="0" y2="0">' +
      '<stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".2"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>' +
      '<radialGradient id="sbGlow" cx=".5" cy=".5" r=".5">' +
      '<stop offset="0" style="stop-color:var(--status)" stop-opacity=".62"/><stop offset=".6" style="stop-color:var(--status)" stop-opacity=".2"/><stop offset="1" style="stop-color:var(--status)" stop-opacity="0"/></radialGradient>' +
      '<linearGradient id="sbBeam" x1="0" x2="1" y1="0" y2="0">' +
      '<stop offset="0" style="stop-color:var(--car-lamp)" stop-opacity=".5"/><stop offset="1" style="stop-color:var(--car-lamp)" stop-opacity="0"/></linearGradient>' +
      '<linearGradient id="sbRim" x1="0" x2="1" y1="0" y2="1">' +
      '<stop offset="0" stop-color="#fff" stop-opacity=".6"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".25"/></linearGradient>' +
      '<filter id="sbBlur" x="-10%" y="-60%" width="120%" height="220%"><feGaussianBlur stdDeviation="4"/></filter>' +
      '<filter id="sbLampGlow" x="-60%" y="-120%" width="220%" height="340%"><feGaussianBlur stdDeviation="3"/></filter>' +
      '<clipPath id="sbClip"><path d="' + BODY + '"/></clipPath>' +
      '</defs>' +
      // ground: glow, shadow, road line
      '<ellipse class="car-glow" cx="' + (cx + 2) + '" cy="' + (GROUND + 3) + '" rx="214" ry="18" fill="url(#sbGlow)"/>' +
      '<ellipse class="car-floor" cx="' + (cx + 2) + '" cy="' + (GROUND + 1) + '" rx="176" ry="5.5" filter="url(#sbBlur)"/>' +
      '<line class="car-ground" x1="8" x2="' + (W - 8) + '" y1="' + (GROUND + 0.5) + '" y2="' + (GROUND + 0.5) + '"/>' +
      // headlight beam (fog and rain)
      '<path class="car-beam" d="M418 84L' + W + ' 56L' + W + ' 116L418 90Z" fill="url(#sbBeam)"/>' +
      '<ellipse class="tail-spill" cx="38" cy="82" rx="44" ry="20" filter="url(#sbBlur)"/>' +
      '<g id="carBody">' +
      // wheel wells and wheels sit behind the body so the arches frame them
      '<circle class="arch" cx="' + REAR_X + '" cy="' + WHEEL_Y + '" r="' + ARCH_R + '"/>' +
      '<circle class="arch" cx="' + FRONT_X + '" cy="' + WHEEL_Y + '" r="' + ARCH_R + '"/>' +
      wheelMarkup(REAR_X) +
      wheelMarkup(FRONT_X) +
      // body
      '<path class="body" d="' + BODY + '"/>' +
      '<g clip-path="url(#sbClip)">' +
      '<rect x="40" y="58" width="390" height="74" fill="url(#sbSheen)"/>' +
      '<rect x="40" y="110" width="390" height="24" fill="url(#sbRocker)"/>' +
      '<path class="crease-hi" d="M54 70.4C118 63.6 250 61.6 330 63.8C362 66 392 74 417 85.6"/>' +
      '<path class="crease-lo" d="M150 108C200 100.6 288 98.6 322 104"/>' +
      '<path class="sill-line" d="M62 120.4L88 120.4M155 120.4L318 120.4M385 120.4L410 120.4"/>' +
      '</g>' +
      '<path class="body-edge" d="' + BODY + '"/>' +
      // glass roof and windows
      '<path class="glass" d="' + GLASS_REAR + '"/>' +
      '<path class="glass" d="' + GLASS_FRONT + '"/>' +
      '<path class="pillar" d="M206 31.4L213.6 31L214.4 60.4L206 60.4Z"/>' +
      '<g clip-path="url(#sbClip)"><path class="reflect" d="M150 59L186 36L202 33L172 60Z"/><path class="reflect" d="M236 59L262 33L278 35L266 59Z"/></g>' +
      '<path class="glass-edge" d="M126 60.4C144 53.5 170 39.5 199 31.8M213.6 31C229 29.8 246 29.6 261 30.4C281 32 301 44 322.5 60.4"/>' +
      // door seams and handles
      '<path class="seam" d="M210 61L210 121M316 66C318.4 86 318.4 106 314 122M140 63C138 84 137 102 135 119"/>' +
      '<rect class="handle" x="150" y="68.6" width="17" height="3.4" rx="1.7"/>' +
      '<rect class="handle" x="226" y="67.8" width="17" height="3.4" rx="1.7"/>' +
      // mirror
      '<path class="mirror" d="M316 61.2L331 60.4C335 60.3 336.2 63.8 333 65.4L320 67.6Z"/>' +
      // lamps
      '<path class="lamp-glow" d="M394 78.6L417.5 85.6C419.6 86.3 419 88.6 417 88.4L396 82.4Z" filter="url(#sbLampGlow)"/>' +
      '<path class="lamp-head" d="M394 78.6L417.5 85.6C419.6 86.3 419 88.6 417 88.4L396 82.4Z"/>' +
      '<path class="lamp-glow lamp-tail-glow" d="M48.4 86C47.4 78 50.6 72.4 56.6 69.6L84 64" filter="url(#sbLampGlow)"/>' +
      '<path class="lamp-tail" d="M48.4 86C47.4 78 50.6 72.4 56.6 69.6L84 64"/>' +
      '<path class="splitter" d="M417 109.6L424.8 107.8L424.8 113L418.4 115.2Z"/>' +
      '<path class="trunk-lip" d="M58 69C72 66 92 63.4 110 61.4"/>' +
      '</g>'
    );
  }

  function create(svg) {
    svg.setAttribute('viewBox', '0 ' + VIEW_Y + ' ' + W + ' ' + VIEW_H);
    svg.innerHTML = markup();
    const body = svg.querySelector('#carBody');

    /* view: { status: 'SAFE'|'WARNING'|'CRITICAL'|null, mods: [], weather, speedKmh, playing } */
    function update(view) {
      const status = view.status ? view.status.toLowerCase() : 'idle';
      svg.dataset.status = status;
      svg.dataset.weather = view.weather === 'Heavy Rain' ? 'rain' : view.weather === 'Fog' ? 'fog' : 'clear';
      svg.dataset.moving = view.playing && view.speedKmh > 0 ? 'true' : 'false';
      svg.style.setProperty('--spin-dur', Math.max(0.9, 7 - view.speedKmh / 20).toFixed(2) + 's');
      const mods = view.mods || [];
      body.classList.toggle('mod-perf', mods.indexOf('performanceTires') !== -1);
      body.classList.toggle('mod-worn', mods.indexOf('wornTires') !== -1);
      body.classList.toggle('mod-brakes', mods.indexOf('upgradedBrakes') !== -1);
      svg.classList.toggle('is-braking', status === 'critical');
    }

    return { update: update };
  }

  (root.ATM = root.ATM || {}).carSide = { create: create };
})(window);
