/*
 * road-view.js
 * Top-down view of a generic EV sedan, the road ahead, the object detected by the
 * sensors, and the stopping-distance zones.
 *
 * The car is an original generic design. It does not copy any real vehicle or brand.
 * Distances use a compressed (square-root) scale so that both 10 m and 200 m fit.
 * The scale ticks on the road show the real distances.
 */
(function (root) {
  'use strict';

  const W = 400;
  const H = 600;
  const NOSE_Y = 440; // y of the car's nose
  const CAR_X = 200; // centre line of the ego lane
  const TOP_Y = 40; // y of the farthest distance shown
  const MAX_M = 200;
  const K = (NOSE_Y - TOP_Y) / Math.sqrt(MAX_M);
  const TICKS = [10, 25, 50, 100, 150]; // 200 m is the top edge and would sit under the chips
  const OBJECT_LEN = 52;
  const OBJECT_W = 44;
  const CORRIDOR_X = 160;
  const CORRIDOR_W = 80;

  const yAt = (m) => NOSE_Y - K * Math.sqrt(Math.max(0, Math.min(m, MAX_M)));
  const f1 = (n) => n.toFixed(1);

  const reduceMotion = () =>
    typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Car outline, nose at y=0, tail at y=125, centred on x=0. 1 unit is about 3.8 cm. */
  const BODY =
    'M0 0C9 0 19 2 24 9C27 14 28.5 22 29 32L29.5 62C29.5 78 29 92 27.5 104C26 114 21 122 13 124C8 125 4 125 0 125' +
    'C-4 125 -8 125 -13 124C-21 122 -26 114 -27.5 104C-29 92 -29.5 78 -29.5 62L-29 32C-28.5 22 -27 14 -24 9C-19 2 -9 0 0 0Z';

  function carMarkup() {
    return (
      '<g class="car" id="car" transform="translate(' + CAR_X + ' ' + NOSE_Y + ')">' +
      // soft ground shadow
      '<path class="car-shadow" d="' + BODY + '" transform="translate(2 4)" filter="url(#blur4)"/>' +
      // wheels sit under the body so only the outer edge shows
      '<g class="wheels">' +
      [[-1, 25], [1, 25], [-1, 101], [1, 101]]
        .map(function (w) {
          const x = w[0] * 29;
          return (
            '<rect class="wheel" x="' + (x - 3.25) + '" y="' + (w[1] - 8.5) + '" width="6.5" height="17" rx="2.4"/>' +
            '<rect class="caliper" x="' + (w[0] > 0 ? x + 3.4 : x - 4.6) + '" y="' + (w[1] - 5) + '" width="1.2" height="10" rx=".6"/>'
          );
        })
        .join('') +
      '</g>' +
      '<path class="car-body" d="' + BODY + '"/>' +
      // hood creases
      '<path class="car-line" d="M-9 4C-12 14-13 24-13 34M9 4C12 14 13 24 13 34"/>' +
      // twin gold stripes on the bonnet and the boot lid
      '<path class="car-stripe" d="M-2.4 6L-2.4 33M2.4 6L2.4 33M-2.4 107L-2.4 117M2.4 107L2.4 117"/>' +
      // side mirrors
      '<rect class="car-mirror" x="28.4" y="43" width="5.6" height="6.4" rx="2.2"/>' +
      '<rect class="car-mirror" x="-34" y="43" width="5.6" height="6.4" rx="2.2"/>' +
      // glass: windshield, glass roof, rear window
      '<path class="car-glass" d="M-18 52L-15 39Q0 34.5 15 39L18 52Q0 47.5-18 52Z"/>' +
      '<path class="car-roof" d="M-18.5 53Q0 49 18.5 53L18.5 88Q0 91.5-18.5 88Z"/>' +
      '<path class="car-glass" d="M-18.5 89.5Q0 93 18.5 89.5L16 101Q0 105-16 101Z"/>' +
      '<path class="car-glint" d="M-12 56L-4 56L-12 80Z"/>' +
      // front camera and radar
      '<circle class="car-camera-ring" cx="0" cy="40.5" r="3.4"/><circle class="car-camera" cx="0" cy="40.5" r="1.6"/>' +
      '<rect class="car-radar" x="-7" y="1.2" width="14" height="2.4" rx="1.2"/>' +
      // lights
      '<path class="light-head" d="M9.5 2.6Q18 3 23 9M-9.5 2.6Q-18 3-23 9"/>' +
      '<path class="light-tail" d="M-20 120.6Q0 124.4 20 120.6"/>' +
      '</g>'
    );
  }

  function objectMarkup() {
    // A generic stopped vehicle seen from behind and above. Its rear edge sits at y=0.
    const x = -OBJECT_W / 2;
    const y = -OBJECT_LEN;
    return (
      '<g class="object" id="object">' +
      '<rect class="object-body" x="' + x + '" y="' + y + '" width="' + OBJECT_W + '" height="' + OBJECT_LEN + '" rx="10"/>' +
      '<path class="object-glass" d="M-14 -11L14 -11L12 -28L-12 -28Z"/>' +
      '<rect class="object-hazard" x="-19" y="-5" width="7" height="3.4" rx="1.4"/>' +
      '<rect class="object-hazard" x="12" y="-5" width="7" height="3.4" rx="1.4"/>' +
      '</g>'
    );
  }

  function ticksMarkup() {
    return TICKS.map(function (m) {
      const y = yAt(m);
      return (
        '<line class="tick-line" x1="22" x2="378" y1="' + y + '" y2="' + y + '"/>' +
        '<text class="tick-text" x="30" y="' + (y - 5) + '">' + m + ' m</text>'
      );
    }).join('');
  }

  function build(svg) {
    const coneHalf = 150;
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    svg.innerHTML =
      '<defs>' +
      '<linearGradient id="gBody" x1="0" x2="1" y1="0" y2="0">' +
      '<stop offset="0" style="stop-color:var(--car-lo)"/><stop offset=".32" style="stop-color:var(--car-hi)"/>' +
      '<stop offset=".68" style="stop-color:var(--car-hi)"/><stop offset="1" style="stop-color:var(--car-lo)"/></linearGradient>' +
      '<linearGradient id="gCone" x1="0" x2="0" y1="1" y2="0">' +
      '<stop offset="0" style="stop-color:var(--accent);stop-opacity:.26"/><stop offset="1" style="stop-color:var(--accent);stop-opacity:0"/></linearGradient>' +
      '<linearGradient id="gFog" x1="0" x2="0" y1="0" y2="1">' +
      '<stop offset="0" style="stop-color:var(--fx-fog);stop-opacity:.92"/><stop offset=".55" style="stop-color:var(--fx-fog);stop-opacity:.42"/>' +
      '<stop offset="1" style="stop-color:var(--fx-fog);stop-opacity:0"/></linearGradient>' +
      '<radialGradient id="gGlare" cx=".5" cy=".5" r=".5">' +
      '<stop offset="0" style="stop-color:var(--glare-color);stop-opacity:1"/><stop offset=".45" style="stop-color:var(--glare-color);stop-opacity:.45"/>' +
      '<stop offset="1" style="stop-color:var(--glare-color);stop-opacity:0"/></radialGradient>' +
      '<pattern id="pHatch" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="7" style="stroke:var(--crit);stroke-width:2.2;stroke-opacity:.55"/></pattern>' +
      '<pattern id="pRain" width="46" height="70" patternUnits="userSpaceOnUse" patternTransform="rotate(14)">' +
      '<line x1="6" y1="4" x2="6" y2="26"/><line x1="30" y1="34" x2="30" y2="58"/><line x1="18" y1="48" x2="18" y2="62"/></pattern>' +
      '<filter id="blur4" x="-20%" y="-10%" width="140%" height="120%"><feGaussianBlur stdDeviation="4"/></filter>' +
      '<clipPath id="clipView"><rect width="' + W + '" height="' + H + '" rx="0"/></clipPath>' +
      '</defs>' +
      '<g clip-path="url(#clipView)">' +
      '<rect class="shoulder" width="' + W + '" height="' + H + '"/>' +
      '<rect class="road" x="22" y="0" width="356" height="' + H + '"/>' +
      '<line class="road-edge" x1="22" x2="22" y1="0" y2="' + H + '"/><line class="road-edge" x1="378" x2="378" y1="0" y2="' + H + '"/>' +
      '<line class="lane-dash" id="laneL" x1="140" x2="140" y1="-60" y2="' + (H + 60) + '"/>' +
      '<line class="lane-dash" id="laneR" x1="260" x2="260" y1="-60" y2="' + (H + 60) + '"/>' +
      ticksMarkup() +
      '<polygon class="cone" points="' + CAR_X + ',' + NOSE_Y + ' ' + (CAR_X - coneHalf) + ',' + TOP_Y + ' ' + (CAR_X + coneHalf) + ',' + TOP_Y + '"/>' +
      // stopping-distance zones: warning band, braking, reaction
      '<rect class="zone zone-warn" id="zWarn" x="' + CORRIDOR_X + '" width="' + CORRIDOR_W + '"/>' +
      '<rect class="zone zone-brake" id="zBrake" x="' + CORRIDOR_X + '" width="' + CORRIDOR_W + '"/>' +
      '<rect class="zone zone-react" id="zReact" x="' + CORRIDOR_X + '" width="' + CORRIDOR_W + '"/>' +
      '<line class="measure" id="measure" x1="' + CAR_X + '" x2="' + CAR_X + '" y1="' + NOSE_Y + '"/>' +
      // fog sits behind the object and the car so both stay readable
      '<rect class="fx-fog" width="' + W + '" height="330" fill="url(#gFog)"/>' +
      objectMarkup() +
      carMarkup() +
      '<g class="fx-rain"><rect class="fx-rain-rect" x="-60" y="-70" width="520" height="' + (H + 140) + '" fill="url(#pRain)"/></g>' +
      '<circle class="fx-glare" id="glare" cx="338" cy="46" r="190" fill="url(#gGlare)"/>' +
      // zone labels
      '<g id="lblStop" class="zlabel"><rect class="zlabel-key zk-brake" width="9" height="9" rx="2"/><text class="zlabel-text" x="14" y="8.5"></text></g>' +
      '<g id="lblWarn" class="zlabel"><rect class="zlabel-key zk-warn" width="9" height="9" rx="2"/><text class="zlabel-text" x="14" y="8.5"></text></g>' +
      '<g id="lblObj" class="olabel"><text class="olabel-name" text-anchor="end" x="0" y="0">OBJECT</text><text class="olabel-value" text-anchor="end" x="0" y="15"></text></g>' +
      // readout chips
      '<g id="chipWeather" class="chip" transform="translate(32 26)"><rect class="chip-bg" height="24" rx="12"/><text class="chip-text" x="12" y="16"></text></g>' +
      '<g id="chipGlare" class="chip" transform="translate(300 26)"><rect class="chip-bg" height="24" rx="12"/><text class="chip-text" x="12" y="16"></text></g>' +
      '<text class="car-caption" id="caption" x="' + CAR_X + '" y="588" text-anchor="middle"></text>' +
      '</g>';
  }

  function create(svg) {
    build(svg);
    const $ = (id) => svg.querySelector('#' + id);
    const el = {
      car: $('car'),
      object: $('object'),
      measure: $('measure'),
      zWarn: $('zWarn'),
      zBrake: $('zBrake'),
      zReact: $('zReact'),
      lblStop: $('lblStop'),
      lblWarn: $('lblWarn'),
      lblObj: $('lblObj'),
      glare: $('glare'),
      chipWeather: $('chipWeather'),
      chipGlare: $('chipGlare'),
      caption: $('caption'),
    };

    let current = null; // values currently painted (metres)
    let frame = 0;
    let first = true;

    function setChip(g, text) {
      const t = g.querySelector('text');
      t.textContent = text;
      g.querySelector('rect').setAttribute('width', Math.round(text.length * 6.9 + 24));
    }

    /* Paint distances (metres) to the SVG. */
    function paint(v) {
      const yObj = yAt(v.obj);
      el.object.setAttribute('transform', 'translate(' + CAR_X + ' ' + yObj + ')');
      el.measure.setAttribute('y2', yObj);

      const yReact = yAt(v.reaction);
      const yStop = yAt(v.stop);
      const yWarn = yAt(v.warn);
      el.zReact.setAttribute('y', yReact);
      el.zReact.setAttribute('height', Math.max(0, NOSE_Y - yReact));
      el.zBrake.setAttribute('y', yStop);
      el.zBrake.setAttribute('height', Math.max(0, yReact - yStop));
      el.zWarn.setAttribute('y', yWarn);
      el.zWarn.setAttribute('height', Math.max(0, yStop - yWarn));

      const stopLabelY = Math.max(yStop, 70);
      const warnLabelY = Math.max(Math.min(yWarn, stopLabelY - 17), 52);
      el.lblStop.setAttribute('transform', 'translate(' + (CORRIDOR_X + CORRIDOR_W + 8) + ' ' + (stopLabelY - 5) + ')');
      el.lblWarn.setAttribute('transform', 'translate(' + (CORRIDOR_X + CORRIDOR_W + 8) + ' ' + (warnLabelY - 5) + ')');
      el.lblObj.setAttribute('transform', 'translate(' + (CORRIDOR_X - 10) + ' ' + (yObj - OBJECT_LEN / 2 - 8) + ')');
    }

    function tween(target) {
      cancelAnimationFrame(frame);
      if (first || reduceMotion() || !current) {
        current = Object.assign({}, target);
        paint(current);
        return;
      }
      const from = Object.assign({}, current);
      const t0 = performance.now();
      const dur = 520;
      (function step(now) {
        const p = Math.min(1, (now - t0) / dur);
        const e = 1 - Math.pow(1 - p, 3);
        const v = {};
        Object.keys(target).forEach(function (k) {
          v[k] = from[k] + (target[k] - from[k]) * e;
        });
        current = v;
        paint(v);
        if (p < 1) frame = requestAnimationFrame(step);
      })(t0);
    }

    /**
     * view: { speedKmh, glarePct, distanceM, weather, status, reactionM, stopM, warnM,
     *         vehicle: { mu, brakeEfficiency, mods[] }, playing }
     */
    function update(view) {
      const weather = view.weather === 'Heavy Rain' ? 'rain' : view.weather === 'Fog' ? 'fog' : 'clear';
      const relation = view.distanceM < view.stopM ? 'inside' : view.distanceM < view.warnM ? 'near' : 'clear';
      svg.dataset.weather = weather;
      svg.dataset.status = view.status.toLowerCase();
      svg.dataset.relation = relation;
      svg.dataset.playing = view.playing ? 'true' : 'false';

      // lane markings scroll faster at higher speed (only while a run is playing)
      const pxPerS = Math.max(8, view.speedKmh * 1.6);
      svg.style.setProperty('--scroll-dur', (48 / pxPerS).toFixed(3) + 's');
      svg.dataset.moving = view.speedKmh > 0 ? 'true' : 'false';

      // modifications are visible on the car
      const mods = view.vehicle.mods;
      el.car.classList.toggle('mod-perf', mods.indexOf('performanceTires') !== -1);
      el.car.classList.toggle('mod-worn', mods.indexOf('wornTires') !== -1);
      el.car.classList.toggle('mod-brakes', mods.indexOf('upgradedBrakes') !== -1);
      el.car.classList.toggle('braking', view.status === 'CRITICAL');

      // glare overlay strength follows the camera glare value
      el.glare.style.opacity = String(Math.min(0.9, (view.glarePct / 100) * 0.95));

      el.lblStop.querySelector('text').textContent = 'Stop ' + f1(view.stopM) + ' m';
      el.lblWarn.querySelector('text').textContent = '1.5× ' + f1(view.warnM) + ' m';
      el.lblObj.querySelector('.olabel-value').textContent = view.distanceM + ' m';

      setChip(el.chipWeather, view.weather);
      setChip(el.chipGlare, 'Glare ' + view.glarePct + '%');
      const glareW = Number(el.chipGlare.querySelector('rect').getAttribute('width'));
      el.chipGlare.setAttribute('transform', 'translate(' + (W - 32 - glareW) + ' 26)');

      el.caption.textContent =
        view.vehicle.name + '  ·  μ ' + view.vehicle.mu.toFixed(2) + '  ·  brakes ' + view.vehicle.brakeEfficiency.toFixed(2);

      tween({ obj: view.distanceM, reaction: view.reactionM, stop: view.stopM, warn: view.warnM });
      first = false;
    }

    return { update: update };
  }

  (root.ATM = root.ATM || {}).roadView = { create: create };
})(window);
