/*
 * engine.js
 * The rule engine. Pure functions only: no DOM, no timers, no randomness.
 * Input is a sensor sample plus a vehicle; output is a status and the reasons.
 *
 * Assumption: the object ahead is stationary, so closing speed equals own speed.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./config'));
  else (root.ATM = root.ATM || {}).engine = factory(root.ATM.config);
})(typeof self !== 'undefined' ? self : this, function (config) {
  'use strict';

  const STATUS = { SAFE: 'SAFE', WARNING: 'WARNING', CRITICAL: 'CRITICAL' };
  const SEVERITY = { SAFE: 0, WARNING: 1, CRITICAL: 2 };

  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
  const round = (n, places) => {
    const f = Math.pow(10, places);
    return Math.round(n * f) / f;
  };

  /**
   * Build the effective vehicle from a base profile and active modifications.
   * Duplicate modification ids are applied once. Values are clamped to sane limits.
   */
  function resolveVehicle(profileId, activeMods, catalog) {
    const cat = catalog || config;
    const base = cat.profiles[profileId];
    if (!base) throw new Error('Unknown vehicle profile: ' + profileId);

    let mu = base.mu;
    let brake = base.brakeEfficiency;
    const applied = [];
    (activeMods || []).forEach(function (id) {
      if (applied.indexOf(id) !== -1) return;
      const mod = cat.mods[id];
      if (!mod) throw new Error('Unknown modification: ' + id);
      if (mod.mu) mu += mod.mu;
      if (mod.brakeEfficiency) brake += mod.brakeEfficiency;
      applied.push(id);
    });

    const lim = cat.limits || config.limits;
    return {
      profileId: base.id,
      name: base.name,
      mu: clamp(round(mu, 2), lim.muMin, lim.muMax),
      brakeEfficiency: clamp(round(brake, 2), lim.brakeMin, lim.brakeMax),
      reactionTimeS: base.reactionTimeS,
      mods: applied,
    };
  }

  /** Weather multiplier for grip. Unknown weather is a programming error, not a default. */
  function gripFactor(weather) {
    const f = config.weatherGrip[weather];
    if (typeof f !== 'number') throw new Error('Unknown weather: ' + weather);
    return f;
  }

  /**
   * Stopping distance split into reaction and braking parts (metres).
   *   v = speed / 3.6
   *   d_stop = v * t_reaction + v^2 / (2 * mu * g * brake_efficiency)
   * where mu is the vehicle grip multiplied by the weather factor.
   */
  function stoppingBreakdown(speedKmh, vehicle, weather) {
    const v = Math.max(0, speedKmh) / 3.6;
    const mu = vehicle.mu * gripFactor(weather);
    const reactionM = v * vehicle.reactionTimeS;
    const brakingM = (v * v) / (2 * mu * config.gravity * vehicle.brakeEfficiency);
    return { reactionM: reactionM, brakingM: brakingM, totalM: reactionM + brakingM };
  }

  function stoppingDistanceM(speedKmh, vehicle, weather) {
    return stoppingBreakdown(speedKmh, vehicle, weather).totalM;
  }

  /** Time to collision in seconds. Infinity when the vehicle is not moving. */
  function timeToCollisionS(distanceM, speedKmh) {
    if (!(speedKmh > 0)) return Infinity;
    return distanceM / (speedKmh / 3.6);
  }

  const f1 = (n) => n.toFixed(1);
  const f2 = (n) => n.toFixed(2);

  /**
   * Speed at which the speed rule warns. A scenario can set its own through
   * `options.speedAlertKmh` (a motorway and a city street do not share one limit).
   * Without it the default from config.js applies.
   */
  function speedAlertKmh(options) {
    const own = options && options.speedAlertKmh;
    return typeof own === 'number' && own > 0 ? own : config.thresholds.speedWarningKmh;
  }

  /**
   * Evaluate one sensor sample. Returns status, every triggered reason, and the derived numbers.
   * options (optional): { speedAlertKmh }. A scenario object can be passed as is.
   */
  function evaluateScan(sample, vehicle, options) {
    const t = config.thresholds;
    const speedAlert = speedAlertKmh(options);
    const stop = stoppingBreakdown(sample.speedKmh, vehicle, sample.weather);
    const ttc = timeToCollisionS(sample.distanceM, sample.speedKmh);
    const warnLimitM = t.stoppingWarningFactor * stop.totalM;

    const critical = [];
    const warning = [];

    if (ttc < t.ttcCriticalS) {
      critical.push('TTC ' + f2(ttc) + ' s is below ' + t.ttcCriticalS + ' s');
    }
    if (sample.distanceM < stop.totalM) {
      critical.push('Object at ' + sample.distanceM + ' m is inside the ' + f1(stop.totalM) + ' m stopping distance');
    }

    if (ttc >= t.ttcCriticalS && ttc < t.ttcWarningS) {
      warning.push('TTC ' + f2(ttc) + ' s is below ' + t.ttcWarningS + ' s');
    }
    if (sample.distanceM >= stop.totalM && sample.distanceM < warnLimitM) {
      warning.push(
        'Object at ' + sample.distanceM + ' m is within ' + t.stoppingWarningFactor + '× the stopping distance (' + f1(warnLimitM) + ' m)'
      );
    }
    if (sample.speedKmh >= speedAlert) {
      warning.push('Speed ' + sample.speedKmh + ' km/h is at or above ' + speedAlert + ' km/h');
    }
    if (sample.glarePct >= t.glareWarningPct) {
      warning.push('Camera glare ' + sample.glarePct + '% is at or above ' + t.glareWarningPct + '%');
    }
    const lowGripLimit = t.lowGripSpeedKmh[sample.weather];
    if (lowGripLimit !== undefined && sample.speedKmh > lowGripLimit) {
      warning.push(sample.weather + ': speed ' + sample.speedKmh + ' km/h is above the ' + lowGripLimit + ' km/h limit');
    }

    const status = critical.length ? STATUS.CRITICAL : warning.length ? STATUS.WARNING : STATUS.SAFE;
    const reasons = critical.concat(warning);
    const reasonDetails = critical
      .map(function (text) {
        return { level: STATUS.CRITICAL, text: text };
      })
      .concat(
        warning.map(function (text) {
          return { level: STATUS.WARNING, text: text };
        })
      );

    return {
      status: status,
      reasons: reasons.length ? reasons : ['No alert rules triggered.'],
      reasonDetails: reasonDetails,
      ttcS: ttc,
      stoppingDistanceM: stop.totalM,
      reactionM: stop.reactionM,
      brakingM: stop.brakingM,
      warnLimitM: warnLimitM,
    };
  }

  /** Evaluate a whole run. Also reports status counts and the first most severe scan. */
  function evaluateRun(samples, vehicle, options) {
    const counts = { SAFE: 0, WARNING: 0, CRITICAL: 0 };
    let worstIndex = 0;
    const scans = samples.map(function (sample, i) {
      const result = evaluateScan(sample, vehicle, options);
      counts[result.status] += 1;
      return Object.assign({}, sample, result);
    });
    scans.forEach(function (scan, i) {
      if (SEVERITY[scan.status] > SEVERITY[scans[worstIndex].status]) worstIndex = i;
    });
    return { scans: scans, counts: counts, worstIndex: worstIndex };
  }

  return {
    STATUS: STATUS,
    SEVERITY: SEVERITY,
    resolveVehicle: resolveVehicle,
    gripFactor: gripFactor,
    speedAlertKmh: speedAlertKmh,
    stoppingBreakdown: stoppingBreakdown,
    stoppingDistanceM: stoppingDistanceM,
    timeToCollisionS: timeToCollisionS,
    evaluateScan: evaluateScan,
    evaluateRun: evaluateRun,
  };
});
